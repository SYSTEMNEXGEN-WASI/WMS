if(typeof(promptengine_skin) != 'undefined' && typeof(promptengine_style) != 'undefined' && typeof(promptengine_lang) != 'undefined') {
	initDom(promptengine_skin, promptengine_style, promptengine_lang);
	styleSheet();
}