﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using DXBMS;

namespace DXBMS.Modules.Setup
{
    public partial class URF : System.Web.UI.Page
    {

        SysFunction sysFunc = new SysFunction();
        SysFunctions sysFuncs = new SysFunctions();
        DataSet ds;
        Transaction ObjTrans = new Transaction();
        clsLookUp clslook = new clsLookUp();
        DataTable dt = new DataTable();
        SqlTransaction Trans;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                if (!string.IsNullOrEmpty((string)Session["LookUpData"]))
                {

                    Set_values(Session["LookUpData"].ToString());

                }
            }
            if (!IsPostBack)
            {
                createGrid();
                txtURFDate.Text = DateTime.Now.Date.ToString("dd-MM-yyyy");
            }
            Session["LookUpData"] = string.Empty;

        }

        protected void imgVehChassisNo_Click(object sender, ImageClickEventArgs e)
        {
            ViewState["lookupid"] = 3; ViewState["ixd1"] = 1; ViewState["ixd2"] = 2; ViewState["ixd3"] = 3;
            string sql = "Select  ChassisNo [Chassis No],RegNo [Reg No], EngineNo [Engine No], C.CusDesc [Customer] from CustomerVehicle A inner join Customer C on A.CusCode = C.CusCode and C.DealerCode = A.DealerCode";
            clslook.LU_Get_RecVeh(imgVehChassisNo, ViewState["lookupid"].ToString(), "", sql, "../../../");
        }
        protected void Set_values(string Item)
        {
            if (ViewState["lookupid"].ToString() == "3")
            {

                txtChassis.Text = Item;
                string sql = "SP_Get_VechicleDataForURF '" + Session["DealerCode"].ToString() + "','" + Item + "'";

                DataTable dt = new DataTable();

                dt = sysFunc.GetData(sql);

                if (dt.Rows.Count > 0)
                {
                    // txtreg.Text = dt.Rows[0]["RegNo"].ToString();
                    txtChassis.Text = dt.Rows[0]["ChassisNo"].ToString();
                    txtEngineNo.Text = dt.Rows[0]["EngineNo"].ToString();
                    txtVehicle.Text = dt.Rows[0]["ProdCode"].ToString();
                    txtColor.Text = dt.Rows[0]["ColorDesc"].ToString();
                    txtCusDesc.Text = dt.Rows[0]["CusDesc"].ToString();
                    //txtOldCusCode.Text = dt.Rows[0]["CusCode"].ToString();

                }
                //String query = "SP_Get_CVODataByRegNo '" + Session["DealerCode"].ToString() + "','" + Item + "'";


                //dt = sysFunc.GetData(query);

                //if (dt.Rows.Count > 0)
                //{
                //    gv_URF.DataSource = dt;
                //    gv_URF.DataBind();
                //}

                Session["URFDS"] = dt;
            }


        }




        protected void btnInsert_Click(object sender, EventArgs e)
        {
            if (txtChassis.Text == "")
            {
                sysFuncs.UserMsg(lblMessage, Color.Red, "Chassis No. should not left blank", txtChassis);
                return;
            }
            if (txtNewreg.Text == "")
            {
                sysFuncs.UserMsg(lblMessage, Color.Red, "Registration Feilds should not left blank", txtNewreg);
                return;
            }
            if (txtRemarks.Text == "")
            {
                sysFuncs.UserMsg(lblMessage, Color.Red, "Remarks should not left blank", txtRemarks);
                return;
            }


            DataTable dt = (DataTable)Session["URFDS"];
            // Check value in GridView TextBOX
            foreach (DataRow d in dt.Rows)
            {
                if (d["RegNo"].ToString().ToUpper() == txtNewreg.Text.ToUpper())
                {
                    sysFunc.UserMsg(lblMessage, Color.Red, "Alredy Exist");
                    return;
                }
            }

            try
            {
                string max = sysFuncs.GetNewMaxID("URF", "URFNo", 8, Session["DealerCode"].ToString());
                SqlParameter[] param =
               {
                new SqlParameter("@DealerCode",SqlDbType.Char,5),//0
                new SqlParameter("@URFNo",SqlDbType.Char,8), //1
                new SqlParameter("@URFDate",SqlDbType.DateTime),//2
                new SqlParameter("@RegNo",SqlDbType.VarChar,50),//3
                new SqlParameter("@ChassisNo",SqlDbType.VarChar,50),//4
                new SqlParameter("@EngineNo",SqlDbType.VarChar,50),//5
                new SqlParameter("@BrandCode",SqlDbType.Char,3),//6
                new SqlParameter("@ProdCode",SqlDbType.VarChar,10),//7
                new SqlParameter("@VersionCode",SqlDbType.Char,3),//8
                new SqlParameter("@ColorCode",SqlDbType.Char,5),//9
                new SqlParameter("@CusCode",SqlDbType.VarChar,8),//10
                new SqlParameter("@Remarks",SqlDbType.VarChar,50),//11
                new SqlParameter("@UpdUser",SqlDbType.VarChar,50), //12
                new SqlParameter("@UpdDate",SqlDbType.DateTime), //13
                new SqlParameter("@UpdTime",SqlDbType.DateTime), //14
                new SqlParameter("@UpdTerm",SqlDbType.VarChar,50),// 15                             
            };

                param[0].Value = Session["DealerCode"].ToString();
                param[1].Value = max;
                param[2].Value = sysFunc.SaveDate(txtURFDate.Text);
                param[3].Value = txtNewreg.Text;
                param[4].Value = txtChassis.Text;
                param[5].Value = txtEngineNo.Text;
                param[6].Value = "";
                param[7].Value = txtVehicle.Text;
                param[8].Value = "";
                param[9].Value = "";
                param[10].Value = txtCusDesc.Text;
                param[11].Value = txtRemarks.Text;
                param[12].Value = Session["UserName"].ToString();
                param[13].Value = sysFunc.SaveDate(DateTime.Now.ToString("dd-MM-yyyy"));
                param[14].Value = DateTime.Now;
                param[15].Value = "1";

                if (sysFunc.ExecuteSP_NonQuery("SP_Insert_URF", param))
                {
                    //sysFunc.ClearTextBoxes(Page);
                    createGrid();
                    sysFuncs.UserMsg(lblMessage, Color.Green, "Data Inserted", txtChassis);

                }
                else
                {
                    sysFuncs.UserMsg(lblMessage, Color.Green, "Data Not Inserted", txtChassis);
                }

                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["RegNo"].ToString().ToUpper() == txtNewreg.Text.ToUpper())
                    {
                        sysFunc.UserMsg(lblMessage, Color.Red, "Alredy Exist");
                        return;
                    }
                }

            }
            catch (Exception ex)
            {

                sysFunc.UserMsg(lblMessage, System.Drawing.Color.Red, ex.Message);
            }
        }
        private void createGrid()
        {
            string query = "Select URFNo, Format(URFDate,'dd-MM-yyyy') [URFDate], ChassisNo, RegNo, Remarks from URF where dealercode = '" + Session["DealerCode"].ToString() + "' ";

            DataTable dt = new DataTable();

            dt = sysFunc.GetData(query);

            if (dt != null && dt.Rows.Count > 0)
            {
                gv_URF.DataSource = dt;
                gv_URF.DataBind();
            }

            Session["URFDS"] = dt;
        }
        //private void createGrid()
        //{

        //    DataTable dt = new DataTable();

        //    dt.Columns.Add(new DataColumn("URFNo", typeof(string)));
        //    dt.Columns.Add(new DataColumn("URFDate", typeof(string)));
        //    dt.Columns.Add(new DataColumn("ChassisNo", typeof(string)));
        //    dt.Columns.Add(new DataColumn("CusCode", typeof(string)));
        //    dt.Columns.Add(new DataColumn("RegNo", typeof(string)));
        //    dt.Columns.Add(new DataColumn("Remarks", typeof(string)));
        //    dt.Columns.Add(new DataColumn("UpdUser", typeof(string)));
        //    dt.Columns.Add(new DataColumn("UpdDate", typeof(string)));
        //    dt.Columns.Add(new DataColumn("UpdTime", typeof(string)));
        //    dt.Columns.Add(new DataColumn("UpdTerm", typeof(string)));

        //    gv_URF.DataSource = dt;
        //    gv_URF.DataBind();

        //    Session["URFDS"] = dt;


        //}
        //protected void SelectedPartDetail(string item)
        //{

        //    DataTable dt = new DataTable();
        //    try
        //    {
        //            if (ddlJobCardTypeCode.SelectedValue == "012")
        //            {
        //                txtDep.ReadOnly = false;
        //            }
        //            else
        //            {
        //                txtDep.ReadOnly = true;

        //            }

        protected void gv_URF_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow && !(gv_URF.EditIndex == e.Row.RowIndex))
                {
                    e.Row.Cells[0].Enabled = true;
                }

                if (e.Row.RowType == DataControlRowType.DataRow && (gv_URF.EditIndex == e.Row.RowIndex))
                {
                    TextBox txtChassis = (TextBox)e.Row.FindControl("txtChassis");

                    // txtreg.Text = Session["lblUnitDesc"].ToString();
                }

                if (e.Row.RowType == DataControlRowType.Footer)
                {

                }
            }
            catch (Exception ex)
            {
                // lblMessage.Visible = true;
                //lblMessage.Text = ex.Message;
            }
        }

        protected void gv_URF_DataBound(object sender, EventArgs e)

        {
            try
            {

            }
            catch (Exception ex)
            {
                //lblMessage.Visible = true;
                // lblMessage.Text = ex.Message;
            }
        }




        protected void btnClear_Click(object sender, EventArgs e)
        {
            Session["LookUpData"] = null;
            txtChassis.Text = "";
            txtNewreg.Text = "";
            txtColor.Text = "";
            txtEngineNo.Text = "";
            txtVehicle.Text = "";
            txtCusDesc.Text = "";
            txtRemarks.Text = "";
            txtURFDate.Text = "";
            txtURFNo.Text = "";
            lblMessage.Text = "";
            createGrid();
        }

        protected void gv_URF_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_URF.PageIndex = e.NewPageIndex;
            createGrid();
        }
    }
}