﻿using CConn;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DXBMS.Modules.Setup
{
    public partial class AccCodeAsgmt : System.Web.UI.Page
    {
        clsLookUp clslook = new clsLookUp();
        MainBLL ObjMainBLL = new MainBLL();
        Transaction ObjTrans = new Transaction();
        SysFunction SysFunc = new SysFunction();
        SysFunctions SysFuncs = new SysFunctions();
        DataSet ds = new DataSet();
        static int id = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Session["UserName"] == null)
            {
                Response.Redirect("~/login.aspx");

            }           

            if (!IsPostBack)
            {

                initializeDDLs(ddlExPartCostMkt);
                initializeDDLs(ddlExPartCostCKD);
                initializeDDLs(ddlExPartCostImp);
                initializeDDLs(ddlExPartCostLcl);
                initializeDDLs(ddlExLubCostMkt);
                initializeDDLs(ddlExLubCostLcl);
                initializeDDLs(ddlExCashDis);
                initializeDDLs(ddlExChargeOut);
                initializeDDLs(ddlExBadDate);
                initializeDDLs(ddlExSvcChar);
                initializeDDLs(ddlExFreightChar);
                initializeDDLs(ddlExOtherChar);

                initializeDDLs(ddlInPartSaleMkt);
                initializeDDLs(ddlInPartSaleCKD);
                initializeDDLs(ddlInPartSaleLcl);
                initializeDDLs(ddlInPartSaleImp);
                initializeDDLs(ddlInLubSaleMkt);
                initializeDDLs(ddlInLubSaleLcl);
                initializeDDLs(ddlInSubIncome);
                initializeDDLs(ddlInLabIncome);
                initializeDDLs(ddlInWarantyLab);
                
                initializeDDLs(ddlAssPartStkLcl);
                initializeDDLs(ddlAssPartStkMkt);
                initializeDDLs(ddlAssPartStkCKD);
                initializeDDLs(ddlAssPartStkImp);
                initializeDDLs(ddlAssLubStkMkt);
                initializeDDLs(ddlAssLubStkLcl);

                initializeDDLs(ddlLiabPST);
                initializeDDLs(ddlLiabGST);
                initializeDDLs(ddlLiabExtra);
                initializeDDLs(ddlLiabFur);
                initializeDDLs(ddlLiabWithHold);

                LoadDDLs();
            }

            //

            Session["LookUpData"] = "";
        }

        private void LoadDDLs()
        {
            DataTable dt = SysFunc.GetData("Select * from AccountCodeSetup where DealerCode = '" + Session["DealerCode"].ToString() + "'");

            ddlExPartCostMkt.SelectedValue = dt.Rows[0]["PartsCostofSales(Market)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsCostofSales(Market)"].ToString().Trim();
            ddlExPartCostCKD.SelectedValue = dt.Rows[0]["PartsCostofSales(CKD)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsCostofSales(CKD)"].ToString().Trim();
            ddlExPartCostLcl.SelectedValue = dt.Rows[0]["PartsCostofSales(Local)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsCostofSales(Local)"].ToString().Trim();
            ddlExPartCostImp.SelectedValue = dt.Rows[0]["PartsCostofSales(Imported)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsCostofSales(Imported)"].ToString().Trim();
            ddlExLubCostMkt.SelectedValue = dt.Rows[0]["LubricantCostofSales(Market)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LubricantCostofSales(Market)"].ToString().Trim();
            ddlExLubCostLcl.SelectedValue = dt.Rows[0]["LubricantCostofSales(Local)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LubricantCostofSales(Local)"].ToString().Trim();
            ddlExCashDis.SelectedValue = dt.Rows[0]["CashDiscountTaken"].ToString().Trim() == "" ? "0" : dt.Rows[0]["CashDiscountTaken"].ToString().Trim();
            ddlExChargeOut.SelectedValue = dt.Rows[0]["ChargeOutAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["ChargeOutAccount"].ToString().Trim();
            ddlExBadDate.SelectedValue = dt.Rows[0]["baddebts"].ToString().Trim() == "" ? "0" : dt.Rows[0]["baddebts"].ToString().Trim();
            ddlExSvcChar.SelectedValue = dt.Rows[0]["ServiceChargesAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["ServiceChargesAccount"].ToString().Trim();
            ddlExOtherChar.SelectedValue = dt.Rows[0]["OtherChargesAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["OtherChargesAccount"].ToString().Trim();
            ddlExFreightChar.SelectedValue = dt.Rows[0]["FreightChargesAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["FreightChargesAccount"].ToString().Trim();

            ddlInPartSaleMkt.SelectedValue = dt.Rows[0]["PartsSaleIncome(Market)"].ToString().Trim()     == "" ? "0" : dt.Rows[0]["PartsSaleIncome(Market)"].ToString().Trim();
            ddlInPartSaleCKD.SelectedValue = dt.Rows[0]["PartsSaleIncome(CKD)"].ToString().Trim()       == "" ? "0" : dt.Rows[0]["PartsSaleIncome(CKD)"].ToString().Trim();
            ddlInPartSaleLcl.SelectedValue = dt.Rows[0]["PartsSaleIncome(Local)"].ToString().Trim()      == "" ? "0" : dt.Rows[0]["PartsSaleIncome(Local)"].ToString().Trim();
            ddlInPartSaleImp.SelectedValue = dt.Rows[0]["PartsSaleIncome(Imported)"].ToString().Trim() == "" ? "0" :  dt.Rows[0]["PartsSaleIncome(Imported)"].ToString().Trim();
            ddlInLubSaleMkt.SelectedValue = dt.Rows[0]["LubricnatSaleIncome(Market)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LubricnatSaleIncome(Market)"].ToString().Trim();
            ddlInLubSaleLcl.SelectedValue = dt.Rows[0]["LubricnatSaleIncome(Local)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LubricnatSaleIncome(Local)"].ToString().Trim();
            ddlInSubIncome.SelectedValue = dt.Rows[0]["SubletIncome"].ToString().Trim() == "" ? "0" : dt.Rows[0]["SubletIncome"].ToString().Trim();
            ddlInLabIncome.SelectedValue = dt.Rows[0]["LabourIncome"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LabourIncome"].ToString().Trim();
            ddlInWarantyLab.SelectedValue = dt.Rows[0]["WarrantyLabour"].ToString().Trim() == "" ? "0" : dt.Rows[0]["WarrantyLabour"].ToString().Trim();

            ddlAssPartStkLcl.SelectedValue = dt.Rows[0]["PartsStock(Local)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsStock(Local)"].ToString().Trim();
            ddlAssPartStkMkt.SelectedValue = dt.Rows[0]["PartsStock(Market)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsStock(Market)"].ToString().Trim();
            ddlAssPartStkCKD.SelectedValue = dt.Rows[0]["PartsStock(CKD)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsStock(CKD)"].ToString().Trim();
            ddlAssPartStkImp.SelectedValue = dt.Rows[0]["PartsStock(Imported)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PartsStock(Imported)"].ToString().Trim();
            ddlAssLubStkMkt.SelectedValue = dt.Rows[0]["LubricantStock(Market)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LubricantStock(Market)"].ToString().Trim();
            ddlAssLubStkLcl.SelectedValue = dt.Rows[0]["LubricantStock(Local)"].ToString().Trim() == "" ? "0" : dt.Rows[0]["LubricantStock(Local)"].ToString().Trim();

            ddlLiabPST.SelectedValue = dt.Rows[0]["PSTAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["PSTAccount"].ToString().Trim();
            ddlLiabGST.SelectedValue = dt.Rows[0]["GSTAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["GSTAccount"].ToString().Trim();
            ddlLiabExtra.SelectedValue = dt.Rows[0]["ExtraTax"].ToString().Trim() == "" ? "0" : dt.Rows[0]["ExtraTax"].ToString().Trim();
            ddlLiabFur.SelectedValue = dt.Rows[0]["FurtherAccount"].ToString().Trim() == "" ? "0" : dt.Rows[0]["FurtherAccount"].ToString().Trim();
            ddlLiabWithHold.SelectedValue = dt.Rows[0]["WHTax5"].ToString().Trim() == "" ? "0" : dt.Rows[0]["WHTax5"].ToString().Trim();

        }

        private void initializeDDLs(DropDownList ddl)
        {
            try
            {
                string CCon = CConnection.GetConnStringForAccount();

                SqlDataReader dr = SqlHelper.ExecuteReader(CCon, CommandType.Text, "Select A.contacccode +'-'+  A.SubCode +'-'+  A.subsubcode +'-'+  A.loccode +'-'+  A.DetailCode as AccountCode , A.contacccode +'-'+   A.SubCode +'-'+ A.subsubcode +'-'+ A.loccode +'-'+  A.DetailCode + ' | ' + rtrim(A.DetailDesc) as DetailDesc from GDetail  A where CompCode = '"+Session["DealerCode"].ToString()+"'");

                if (dr.HasRows)
                {
                    ListItem item = new ListItem();
                    item.Text = "Select";
                    item.Value = "0";

                    //AddInAllDDL(item);

                    ddl.Items.Add(item);
                    while (dr.Read())
                    {
                        StringWriter myWriter = new StringWriter();
                        HttpUtility.HtmlDecode(dr["DetailDesc"].ToString().Replace(" ", "&nbsp;"), myWriter);//ddlEmp.Items.Add(myWriter.ToString());
                        item = new ListItem();
                        item.Text = myWriter.ToString();
                        item.Value = dr["AccountCode"].ToString();
                        ddl.Items.Add(item);

                    }
                    dr.Close();
                }
            }
            catch(Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = ex.Message;
            }
            
        }

        private void AddInAllDDL(ListItem item)
        {
            ddlExPartCostMkt.Items.Add(item);
            ddlExPartCostCKD.Items.Add(item);
            ddlExPartCostLcl.Items.Add(item);
            ddlExLubCostMkt.Items.Add(item);
            ddlExLubCostLcl.Items.Add(item);
            ddlExCashDis.Items.Add(item);
            ddlExChargeOut.Items.Add(item);
            ddlExBadDate.Items.Add(item);
            ddlExSvcChar.Items.Add(item);
            ddlExOtherChar.Items.Add(item);
            ddlExFreightChar.Items.Add(item);

            ddlInPartSaleMkt.Items.Add(item);
            ddlInPartSaleCKD.Items.Add(item);
            ddlInPartSaleLcl.Items.Add(item);
            ddlInLubSaleMkt.Items.Add(item);
            ddlInLubSaleLcl.Items.Add(item);
            ddlInSubIncome.Items.Add(item);
            ddlInLabIncome.Items.Add(item);
            ddlInWarantyLab.Items.Add(item);

            ddlAssPartStkLcl.Items.Add(item);
            ddlAssPartStkMkt.Items.Add(item);
            ddlAssPartStkCKD.Items.Add(item);
            ddlAssLubStkMkt.Items.Add(item);

            ddlLiabPST.Items.Add(item);
            ddlLiabGST.Items.Add(item);
            ddlLiabExtra.Items.Add(item);
            ddlLiabFur.Items.Add(item);
            ddlLiabWithHold.Items.Add(item);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
                try
                {

                    SqlParameter[] param = {
                                        new SqlParameter("@DealerCode",SqlDbType.Char),//0
                                        new SqlParameter("@PartsCostofSalesMkt",SqlDbType.Char),//1
                                        new SqlParameter("@PartsCostofSalesCKD",SqlDbType.Char),//2
                                        new SqlParameter("@PartsCostofSaleslcl",SqlDbType.Char),//3
                                        new SqlParameter("@LubricantCostofSalesMkt",SqlDbType.Char),//4
                                        new SqlParameter("@LubricantCostofSalesLcl",SqlDbType.Char),//5                                    
                                        new SqlParameter("@PartsCostofSalesImp",SqlDbType.Char),//6
                                        new SqlParameter("@baddebts",SqlDbType.Char),//7
                                        new SqlParameter("@GSTAccount",SqlDbType.Char),//8
                                        new SqlParameter("@DiscountAccount",SqlDbType.Char),//9
                                        new SqlParameter("@OtherChargesAccount",SqlDbType.Char),//10
                                        new SqlParameter("@PartsSaleIncomeMkt",SqlDbType.Char),//11
                                        new SqlParameter("@PartsSaleIncomeCKD",SqlDbType.Char),//12                                   
                                        new SqlParameter("@PartsSaleIncomeLcl",SqlDbType.Char),//13
                                        new SqlParameter("@PartsSaleIncomeImp",SqlDbType.Char),//14
                                        new SqlParameter("@LubricnatSaleIncomeMkt",SqlDbType.Char),//15
                                        new SqlParameter("@LubricnatSaleIncomeLcl",SqlDbType.Char),//16
                                        new SqlParameter("@SubletIncome",SqlDbType.Char),//17
                                        new SqlParameter("@LabourIncome",SqlDbType.Char),//18
                                        new SqlParameter("@WarrantyLabour",SqlDbType.Char),//19                                   
                                        new SqlParameter("@PartsStockLcl",SqlDbType.Char),//20
                                        new SqlParameter("@PartsStockMkt",SqlDbType.Char),//21
                                        new SqlParameter("@PartsStockCKD",SqlDbType.Char),//22
                                        new SqlParameter("@PartsStockImp",SqlDbType.Char),//23
                                        new SqlParameter("@LubricantStockMkt",SqlDbType.Char),//24
                                        new SqlParameter("@LubricantStockLcl",SqlDbType.Char),//25
                                        new SqlParameter("@PDIFFIAccount",SqlDbType.Char),//26                                    
                                        new SqlParameter("@WarrantyAccount",SqlDbType.Char),//27
                                        new SqlParameter("@OEMAccount",SqlDbType.Char),//28
                                        new SqlParameter("@WHTax5",SqlDbType.Char),//29
                                        new SqlParameter("@WHTax35",SqlDbType.Char),//30
                                        new SqlParameter("@OtherTax",SqlDbType.Char),//31                                    
                                        new SqlParameter("@ExpenseAccount",SqlDbType.Char),//32
                                        new SqlParameter("@CashDiscountTaken",SqlDbType.Char),//33
                                        new SqlParameter("@OEMVendorCode",SqlDbType.Char),//34
                                        new SqlParameter("@VODAccount",SqlDbType.Char),//35
                                        new SqlParameter("@SEDAccount",SqlDbType.Char),//36
                                        new SqlParameter("@ChargeOutAccount",SqlDbType.Char),//37                                    
                                        new SqlParameter("@HandlingAccount",SqlDbType.Char),//38
                                        new SqlParameter("@PSTAccount",SqlDbType.Char),//39
                                        new SqlParameter("@FurtherAccount",SqlDbType.Char),//40
                                        new SqlParameter("@FreightChargesAccount",SqlDbType.Char),
                                        new SqlParameter("@ServiceChargesAccount",SqlDbType.Char),
                                        new SqlParameter("@ExtraTax",SqlDbType.Char),
                                      };

                param[0].Value = Session["DealerCode"].ToString();
                param[1].Value = ddlExPartCostMkt.SelectedValue;
                param[2].Value = ddlExPartCostCKD.SelectedValue;
                param[3].Value = ddlExPartCostLcl.SelectedValue;
                param[4].Value = ddlExLubCostMkt.SelectedValue;
                param[5].Value = ddlExLubCostLcl.SelectedValue;
                param[6].Value = ddlExPartCostImp.SelectedValue;
                param[7].Value = ddlExBadDate.SelectedValue;
                param[8].Value = ddlLiabGST.SelectedValue;
                param[9].Value = ddlExCashDis.SelectedValue;
                param[10].Value = ddlExOtherChar.SelectedValue;
                param[11].Value = ddlInPartSaleMkt.SelectedValue;
                param[12].Value = ddlInPartSaleCKD.SelectedValue;
                param[13].Value = ddlInPartSaleLcl.SelectedValue;
                param[14].Value = ddlInPartSaleImp.SelectedValue;
                param[15].Value = ddlInLubSaleMkt.SelectedValue;
                param[16].Value = ddlInLubSaleLcl.SelectedValue;
                param[17].Value = ddlInSubIncome.SelectedValue;
                param[18].Value = ddlInLabIncome.SelectedValue;
                param[19].Value = ddlInWarantyLab.SelectedValue;
                param[20].Value = ddlAssPartStkLcl.SelectedValue;
                param[21].Value = ddlAssPartStkMkt.SelectedValue;
                param[22].Value = ddlAssPartStkCKD.SelectedValue;
                param[23].Value = ddlAssPartStkImp.SelectedValue;
                param[24].Value = ddlAssLubStkMkt.SelectedValue;
                param[25].Value = ddlAssLubStkLcl.SelectedValue;
                param[26].Value = "";
                param[27].Value = "";
                param[28].Value = "";
                param[29].Value = ddlLiabWithHold.SelectedValue;
                param[30].Value = "";
                param[31].Value = "";
                param[32].Value = "";
                param[33].Value = ddlExCashDis.SelectedValue;
                param[34].Value = "";
                param[35].Value = "";
                param[36].Value = "";
                param[37].Value = ddlExChargeOut.SelectedValue;
                param[38].Value = "";
                param[39].Value = ddlLiabPST.SelectedValue;
                param[40].Value = ddlLiabFur.SelectedValue;
                param[41].Value = ddlExFreightChar.SelectedValue;
                param[42].Value = ddlExSvcChar.SelectedValue;
                param[43].Value = ddlLiabExtra.SelectedValue;

                SysFunc.ExecuteSP_NonQuery("SP_Insert_AccountCodeSetup", param);
                

                lblMsg.Visible = true;
                lblMsg.Text = "Account(s) Saved Successfully";

            }
            catch (Exception ex)
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = ex.Message;
                }
        }

        protected void btnLoad_Click(object sender, EventArgs e)
        {
            LoadDDLs();
        }
    }
}