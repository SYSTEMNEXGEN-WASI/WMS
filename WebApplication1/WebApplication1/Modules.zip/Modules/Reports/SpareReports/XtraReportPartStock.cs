﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace DXBMS.Modules.Reports.SpareReports
{
    public partial class XtraReportPartStock : DevExpress.XtraReports.UI.XtraReport
    {
        public XtraReportPartStock()
        {
            InitializeComponent();
        }

    }
}
