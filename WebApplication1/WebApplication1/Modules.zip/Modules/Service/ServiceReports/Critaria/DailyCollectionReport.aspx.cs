﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using CrystalDecisions.CrystalReports.Engine;
using Microsoft.ApplicationBlocks.Data;
using CrystalDecisions.Shared;
using CConn;
using DXBMS.Data;



namespace DXBMS.Modules.Service.ServiceReports.Critaria
{
    public partial class DailyCollectionReport : System.Web.UI.Page
    {
        static SysFunctions SysFunc = new SysFunctions();
        clsLookUp clslook = new clsLookUp();
        protected void Page_Load(object sender, EventArgs e)
        {
            

            if (this.Session["UserName"] == null)
            {
                Response.Redirect("~/login.aspx");

            }
            if (Page.IsPostBack)
            {

                if (!string.IsNullOrEmpty((string)Session["LookUpData"]))
                {
                    SelectedPartDetail(Session["LookUpData"].ToString());
                }
            }

            if (Request.Params.Get("Name") != null)
            {
                ViewState["Name"] = Request.QueryString["Name"].ToString();
            }
            if (!IsPostBack)
            {
                txtFromDate.Text = txtToDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            }
            Session["LookUpData"] = string.Empty;
        }

        //protected void btnPrint_Click(object sender, EventArgs e)
        //{
        //    ScriptManager.RegisterStartupScript(this, GetType(), "Print", "Print()", true);
        //}

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            ReportDocument RD = new ReportDocument();
            string FDate = SysFunc.SaveDate(txtFromDate.Text).ToString();
            string TDate = SysFunc.SaveDate(txtToDate.Text).ToString();
            DataSet dsRpt = new DataSet();
            DXBMS.Data.DSReports objDsReports = new Data.DSReports();
            

            DataTable dt = new DataTable();
            string sql;

            if (ViewState["Name"].ToString() == "DCR")
            {
                sql = "exec sp_DailyCollectionSP '" + Session["DealerCode"].ToString() + "','" + FDate + "','" + TDate + "'";
                RD.Load(Server.MapPath("../../ServiceReports/ptIncommingPaymentDetail2.rpt"));
                RD.DataDefinition.FormulaFields["ReportTitle"].Text = "\"" + "INCOMMING PAYMENTS DETAIL" + "\"";
            }
            else if (ViewState["Name"].ToString() == "ASI")
            {
                sql = "exec SP_vw_AfterSaleInvoiceDetail_New '" + Session["DealerCode"].ToString() + "','" + FDate + "','" + TDate + "' , '"+txtCusCode.Text+"'";
                RD.Load(Server.MapPath("../../ServiceReports/rptAfterSaleInvoice.rpt"));
                RD.DataDefinition.FormulaFields["ReportTitle"].Text = "\"" + "AFTER SALE INVOICE DETAIL" + "\"";
            }
            
            else
            {
                sql = "exec SP_Aging_Select '" + Session["DealerCode"].ToString() + "','" + FDate + "','" + TDate + "', '" + txtCusCode.Text + "'";
                RD.Load(Server.MapPath("../../ServiceReports/rptAging.rpt"));
                RD.DataDefinition.FormulaFields["ReportTitle"].Text = "\"" + "AGING DETAIL" + "\"";
            }
            dt = SysFunc.GetData(sql);

            RD.PrintOptions.PaperSize = PaperSize.PaperA4;
            
            RD.DataDefinition.FormulaFields["DealerPhone"].Text = "'" + Session["DealerPhone"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerEmail"].Text = "'" + Session["DealerEmail"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerFax"].Text = "'" + Session["DealerFax"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerDesc"].Text = "'" + Session["DealerDesc"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerAddress"].Text = "'" + Session["DealerAddress"].ToString() + "'";
            RD.DataDefinition.FormulaFields["UserID"].Text = "'" + Session["UserID"].ToString() + "'";
            RD.DataDefinition.FormulaFields["Terminal"].Text = "'" + Environment.MachineName + "'";
            
            RD.DataDefinition.FormulaFields["CompanyName"].Text = "'" + Session["DealerDesc"].ToString() + "'";
            RD.DataDefinition.FormulaFields["Pic"].Text = "'" + Server.MapPath("~") + Session["Logo"] + "'";
            //RD.DataDefinition.FormulaFields["Pic"].Text = "'C:\\Users\\u_ahm\\OneDrive\\Documents\\Visual Studio 2010\\Projects\\WebApplication1\\WebApplication1\\Images\\havoline.png'";
            //RD.DataDefinition.FormulaFields["DealershipName"].Text = "'Authorised " + Session["ParentDesc"].ToString() + " Dealership'";
            RD.Database.Tables[0].SetDataSource(dt);

            //crviewer.ReportSource = RD;
            

             //convert and show
            string FilePath = Server.MapPath("~") + "\\Download\\";
            string FileName = "JobCardDetail" + this.Session["DealerCode"].ToString() + DateTime.Now.ToString("ddMMyyyy") + ".pdf";
            string File = FilePath + FileName;

            //RD.ExportToDisk(ExportFormatType.PortableDocFormat, File);
            Session["RD"] = RD;

            string URL = "../../../../Download/rptViewerService.aspx?ReportID=StockBalance";
            string fullURL = "window.open('" + URL + "', '_blank', 'height=800,width=10200,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes,titlebar=no');";
            ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", fullURL, true);
        }

        protected void imgLookup_Click(object sender, ImageClickEventArgs e)
        {
            ViewState["lookupid"] = 1;
            clslook.LU_Get_Customer(imgLookup, ViewState["lookupid"].ToString(), "", "../../../../");

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Close Look Up Window First')", true);
        }

        protected void SelectedPartDetail(string item)
        {

            txtCusCode.Text = item;
        }
    }
}