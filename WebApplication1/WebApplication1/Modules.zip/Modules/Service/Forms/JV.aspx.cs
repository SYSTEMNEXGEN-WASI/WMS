﻿using CConn;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DXBMS.Modules.Service.Forms
{
    public partial class JV : System.Web.UI.Page
    {
        DataSet ds;
        SysFunction sysfun = new SysFunction();
        SysFunctions myFunc = new SysFunctions();

        MainBLL objMBLL = new MainBLL();
        ServiceBL objSBL = new ServiceBL();
        Transaction ObjTrans = new Transaction();
        SqlTransaction Trans;
        static string type ;
        static double totDebit = 0 , totCredit = 0;
        string CCon = CConnection.GetConnStringForAccount();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Session["UserName"] == null)
            {
                Response.Redirect("~/login.aspx");

            }
            if (!IsPostBack)
            {
                //Create_Grid();
                txtVoucherDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                txtVoucherNo.Text = GetNewVoucherNo("GVouMaster", "VouchNo", 3);

                if (Request.Params.Get("CusInv") != null)
                {
                    string leadId = Request.Params.Get("CusInv");

                    type = Request.Params.Get("Type");

                    ViewState["Type"] = type;

                    initializeDDLs(ddlJournalNo);
                    ddlJournalNo.SelectedIndex = 1;

                    if(type == "CI")
                    {
                        LoadJVGrid(leadId);
                    }else if(type == "DS")
                    {
                        LoadCSGrid(leadId);
                    }else
                    {
                        LoadPIGrid(leadId);
                    }
                    

                    ViewState["InvoiceNo"] = leadId;

                    txtTotalDebit.Text = Math.Round((totDebit),0).ToString();
                    txtTotalCredit.Text = Math.Round((totCredit),0).ToString();

                    totCredit = totDebit = 0;
                }
            }
        }

        private void LoadCSGrid(string leadId)
        {
            SqlParameter[] dsParamInv = {
                new SqlParameter("@DealerCode",SqlDbType.Char,5),
                new SqlParameter("@SaleInvNo",SqlDbType.Char,8)
            };

            dsParamInv[0].Value = Session["DealerCode"].ToString();
            dsParamInv[1].Value = leadId;

            totCredit = totDebit = 0;

            DataSet dsCustomerInvoice = new DataSet();
            dsCustomerInvoice = myFunc.FillDataSet("SP_CounterSaleMaster_JV", dsParamInv);

            if (dsCustomerInvoice.Tables[0].Rows.Count > 0)
            {
                string AccountCode = dsCustomerInvoice.Tables[0].Rows[0]["AccountCode"].ToString();
                string Customer = dsCustomerInvoice.Tables[0].Rows[0]["CusDesc"].ToString().Trim();
                double GSTAmount = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["GSTAmount"]);
                double Discount = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["Discount"]);
                double FurtherAmount = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["FurtherAmount"]);
                double OtherCharges = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["OtherCharges"]);
                double InvoiceAmount = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["InvoiceAmount"]);
                double Amount = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["Amount"]);
                double FreightCharges = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["FreightCharges"]);
                double pCkd = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PC.K.D"]);
                double pLocal = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PLocal"]);
                double pMarket = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PMarket"]);
                double lCkd = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LC.K.D"]);
                double lLocal = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LLocal"]);
                double lMarket = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LMarket"]);
               

                string Naration = "Sale Invoice : " + dsCustomerInvoice.Tables[0].Rows[0]["SaleInvNo"].ToString().Trim() + " | " +
                                  "Customer : " + dsCustomerInvoice.Tables[0].Rows[0]["CusDesc"].ToString().Trim();
                

                if (dsCustomerInvoice.Tables[0].Rows[0]["VoucherNo"].ToString().Trim() != "")
                {
                    lblText.Text = "Edit Mode";
                    txtVoucherNo.Text = dsCustomerInvoice.Tables[0].Rows[0]["VoucherNo"].ToString().Trim();
                }

                ds = new DataSet();

                ds.Tables.Add();

                ds.Tables[0].Columns.Add(new DataColumn("AccountCode", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("AccountTitle", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Debit", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Credit", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Naration", typeof(string)));

                Session["JV"] = ds;

                if (InvoiceAmount > 0)
                {
                    AddCustomerDebitAmount(InvoiceAmount, AccountCode,Customer, Naration);
                }

                if (FurtherAmount > 0)
                {
                    string code = GetAccountCode("FurtherAccount");
                    AddCreditAmount(FurtherAmount,code, Naration);
                }

                if (OtherCharges > 0)
                {
                    string code = GetAccountCode("OtherChargesAccount");
                    AddCreditAmount(OtherCharges,code, Naration);
                }

                if (GSTAmount > 0)
                {
                    string code = GetAccountCode("GSTAccount");
                    AddCreditAmount(GSTAmount,code, Naration);
                }

                if (pCkd > 0)
                {
                    string code = GetAccountCode("PartsSaleIncome(CKD)");
                    AddCreditAmount(pCkd,code, Naration);
                }
                if (pLocal > 0)
                {
                    string code = GetAccountCode("PartsSaleIncome(Local)");
                    AddCreditAmount(pLocal,code, Naration);
                }
                if (pMarket > 0)
                {
                    string code = GetAccountCode("PartsSaleIncome(Market)");
                    AddCreditAmount(pMarket,code, Naration);
                }

                if (lLocal > 0)
                {
                    string code = GetAccountCode("LubricnatSaleIncome(Local)");
                    AddCreditAmount(lLocal,code, Naration);
                }
                if (lMarket > 0)
                {
                    string code = GetAccountCode("LubricnatSaleIncome(Market)");
                    AddCreditAmount(lMarket, code, Naration);
                }

                if (FreightCharges > 0)
                {
                    string code = GetAccountCode("FreightChargesAccount");
                    AddCreditAmount(FreightCharges, code, Naration);
                }
                if (Discount > 0)
                {
                    string code = GetAccountCode("CashDiscountTaken");
                    AddDebitAmount(Discount, code, Naration);
                }
            }
        }

        private void initializeDDLs(DropDownList ddl)
        {
            try
            {
                SqlDataReader dr = SqlHelper.ExecuteReader(CCon, CommandType.Text, "Select JournalNo , JournalNo + ' | ' + JournalDesc as JournalDesc from Gjournal  A where A.CompCode = '"+Session["DealerCode"].ToString()+"'");

                if (dr.HasRows)
                {
                    ListItem item = new ListItem();
                    item.Text = "Select";
                    item.Value = "0";

                    //AddInAllDDL(item);

                    ddl.Items.Add(item);
                    while (dr.Read())
                    {
                        StringWriter myWriter = new StringWriter();
                        HttpUtility.HtmlDecode(dr["JournalDesc"].ToString().Replace(" ", "&nbsp;"), myWriter);//ddlEmp.Items.Add(myWriter.ToString());
                        item = new ListItem();
                        item.Text = myWriter.ToString();
                        item.Value = dr["JournalNo"].ToString();
                        ddl.Items.Add(item);

                    }
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                sysfun.UserMsg(lblMsg, Color.Red, ex.Message);
            }

        }
        //private void Create_Grid()
        //{
        //    ds = new DataSet();

        //    ds.Tables.Add();

        //    ds.Tables[0].Columns.Add(new DataColumn("AccountCode", typeof(string)));
        //    ds.Tables[0].Columns.Add(new DataColumn("AccountTitle", typeof(string)));
        //    ds.Tables[0].Columns.Add(new DataColumn("Debit", typeof(string)));
        //    ds.Tables[0].Columns.Add(new DataColumn("Credit", typeof(string)));

        //    DataRow dr = ds.Tables[0].NewRow();
        //    ds.Tables[0].Rows.Add(dr);

        //    gvJV.DataSource = ds.Tables[0];
        //    gvJV.DataBind();

        //    Session["JV"] = ds;
        //}

        private string GetAccountCode(string code)
        {
            DataTable dt = new DataTable();

            string value = "";

            dt = myFunc.GetData("Select ["+ code + "] from AccountCodeSetup where DealerCode = '" + Session["DealerCode"].ToString() + "'");

            if(dt == null)
            {
                return value;
            }
            if (dt.Rows.Count > 0 )
            {
                value = dt.Rows[0][code].ToString();
            }
            return value;
        }

        private string GetAccounttitle(string code)
        {
            try
            {
                string CCon = CConnection.GetConnStringForAccount();
                string value = "";

                SqlDataAdapter dta = new SqlDataAdapter("Select rtrim(A.DetailDesc) as AccountTitle from GDetail  A where A.CompCode = '"+Session["DealerCode"].ToString()+"' and A.contacccode +'-'+  A.SubCode +'-'+  A.subsubcode +'-'+  A.loccode +'-'+  A.DetailCode = '"+ code +"'" , CCon);

                DataTable dt = new DataTable();
                dta.Fill(dt);

                if(dt == null)
                {
                    return value;
                }

                if(dt.Rows.Count > 0)
                {
                    value = dt.Rows[0]["AccountTitle"].ToString();
                }
                

                return value;
            }
            catch (Exception ex)
            {
                sysfun.UserMsg(lblMsg, Color.Red, ex.Message);
                return "";
            }

        }


        private bool PostFlag()
        {
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter("Select Post from GVouMaster where CompCode = '"+Session["DealerCode"].ToString()+"' and VouchNo = '"+txtVoucherNo.Text+"'", CCon);

                DataTable dt = new DataTable();
                dta.Fill(dt);

                if (dt == null)
                {
                    return false;
                }

                if (dt.Rows.Count > 0 && dt.Rows[0]["Post"].ToString() == "Y")
                {
                    
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        protected void btnYes_Click(object sender, EventArgs e)
        {

            if (ddlJournalNo.SelectedIndex == 0)
            {
                sysfun.UserMsg(lblMsg, Color.Red, "Please Select Journal No First");
                return;
            }

            if (PostFlag())
            {
                sysfun.UserMsg(lblMsg, Color.Red, "Can't Edit, the Voucher '" + txtVoucherNo.Text + "' is already Posted");
                return;
            }

            if(txtTotalDebit.Text != txtTotalCredit.Text)
            {
                sysfun.UserMsg(lblMsg, Color.Red, "Can't Save, the Voucher Debit Amount and Credit Amount Should be equal");
                return;
            }

            ds = (DataSet)Session["JV"];
            DataRow[] drr = ds.Tables[0].Select();
            for (int i = 0; i < drr.Length; i++)
            {
                if (ds.Tables[0].Rows[i]["AccountCode"].ToString().Trim() == "" || ds.Tables[0].Rows[i]["AccountCode"].ToString().Trim() == "0")
                {
                    sysfun.UserMsg(lblMsg, Color.Red, "Please Select Account Code First");
                    return;
                }
            }

            string strAutoCode;

            if (lblText.Text.Trim() == "Add Mode")
            {
                strAutoCode = GetNewVoucherNo("GVouMaster", "VouchNo", 3);
            }else
            {
                strAutoCode = txtVoucherNo.Text;
            }

            
            try
            {

                SqlParameter[] param = {
                                   
                                   new SqlParameter("@CompCode",SqlDbType.Char,5),         //0
                                   new SqlParameter("@Booktype",SqlDbType.VarChar,2),      //1
                                   new SqlParameter("@Journalno",SqlDbType.VarChar,4),     //2
                                   new SqlParameter("@VouchNo",SqlDbType.VarChar,50),      //3
                                   new SqlParameter("@SeqNo",SqlDbType.Int),               //4
                                   new SqlParameter("@ContAccCode",SqlDbType.Char,2),      //5
                                   new SqlParameter("@SubCode",SqlDbType.Char,2),          //6
                                   new SqlParameter("@SubSubCode",SqlDbType.Char,2),       //7
                                   new SqlParameter("@LocCode",SqlDbType.Char,2),          //8
                                   new SqlParameter("@DetailCode",SqlDbType.Char,4),       //9
                                   new SqlParameter("@VouchDate",SqlDbType.DateTime),      //10
                                   new SqlParameter("@RecPay",SqlDbType.VarChar,50),       //11
                                   new SqlParameter("@Narration01",SqlDbType.VarChar,200), //12
                                   new SqlParameter("@Narration02",SqlDbType.VarChar,200), //13
                                   new SqlParameter("@ChqBillNo",SqlDbType.VarChar,50),    //14
                                   new SqlParameter("@ChqBillDate",SqlDbType.DateTime),    //15
                                   new SqlParameter("@DebitAmt",SqlDbType.Float),          //16
                                   new SqlParameter("@CreditAmt",SqlDbType.Float),         //17
                                   new SqlParameter("@FYear",SqlDbType.DateTime),          //18
                                   new SqlParameter("@TYear",SqlDbType.DateTime),          //19
                                   new SqlParameter("@DelFlag",SqlDbType.Char,1),          //20
                                   new SqlParameter("@BookNo",SqlDbType.Char,2),           //21
                                   new SqlParameter("@AutoAcc",SqlDbType.VarChar,500),     //22
                                   new SqlParameter("@Post",SqlDbType.Char,1),             //23
                                   new SqlParameter("@Source",SqlDbType.VarChar,50),       //24
                                   new SqlParameter("@AddUser",SqlDbType.Char,50),         //25
                                   new SqlParameter("@AddDate",SqlDbType.DateTime),        //26
                                   new SqlParameter("@AddTime",SqlDbType.DateTime),        //27
                                   new SqlParameter("@AddTerm",SqlDbType.VarChar,50),      //28
                                   new SqlParameter("@CSCode",SqlDbType.Char,8),           //29
                                };
                
                    for (int i = 0; i < drr.Length; i++)
                    {

                    string accountcode = ds.Tables[0].Rows[i]["AccountCode"].ToString();

                    string contAccCode = accountcode.Substring(0, 2);
                    string subCode = accountcode.Substring(3, 2);
                    string subSubCode = accountcode.Substring(6, 2);
                    string locCode = accountcode.Substring(9,2);
                    string detailCode = accountcode.Substring(12, 4);

                    param[0].Value = Session["DealerCode"].ToString();
                    param[1].Value = "JV";
                    param[2].Value = ddlJournalNo.SelectedValue;
                    param[3].Value = strAutoCode;
                    param[4].Value = i + 1;
                    param[5].Value = contAccCode;
                    param[6].Value = subCode;
                    param[7].Value = subSubCode;
                    param[8].Value = locCode;
                    param[9].Value = detailCode;
                    param[10].Value = sysfun.SaveDate(txtVoucherDate.Text);
                    param[11].Value = DBNull.Value;
                    param[12].Value = ds.Tables[0].Rows[i]["Naration"].ToString();
                    param[13].Value = "";
                    param[14].Value = DBNull.Value;
                    param[15].Value = DBNull.Value;

                    if(ds.Tables[0].Rows[i]["Debit"].ToString() != "0.0")
                    {
                        param[16].Value = Convert.ToDouble(ds.Tables[0].Rows[i]["Debit"].ToString());
                    }else
                    {
                        param[16].Value = 0;
                    }

                    if (ds.Tables[0].Rows[i]["Credit"].ToString() != "0.0")
                    {
                        param[17].Value = Convert.ToDouble(ds.Tables[0].Rows[i]["Credit"].ToString());
                    }
                    else
                    {
                        param[17].Value = 0;
                    }

                    param[18].Value = "2018-07-01";
                    param[19].Value = "2019-06-30";
                    param[20].Value = "N";
                    param[21].Value = DBNull.Value; 
                    param[22].Value = DBNull.Value;
                    param[23].Value = "N";
                    param[24].Value = type;
                    param[25].Value = Session["UserName"].ToString();
                    param[26].Value = sysfun.SaveDate(DateTime.Now.ToString("dd-MM-yyyy"));
                    param[27].Value = DateTime.Now;
                    param[28].Value = GlobalVar.mUserIPAddress;
                    param[29].Value = "00/00000";


                    SqlHelper.ExecuteNonQuery(CCon, CommandType.StoredProcedure, "sp_GVouMaster_Insert", param);
                    
                }
                string IQuery = "";



                if (type == "CI" || ViewState["Type"].ToString() == "CI")
                {
                    IQuery = "Update CustomerInvoice set VoucherNo ='" + strAutoCode + "' , VoucherFlag = 'Y' " +
                                             "Where DealerCode='" + Session["DealerCode"].ToString() + "' and InvoiceNo ='" + ViewState["InvoiceNo"].ToString() + "'";
                }else if(type == "CS" || ViewState["Type"].ToString() == "CS")
                {
                    IQuery = "Update CounterSaleMaster set VoucherNo ='" + strAutoCode + "' , VoucherFlag = 'Y' " +
                                             "Where DealerCode='" + Session["DealerCode"].ToString() + "' and SaleInvNo ='" + ViewState["InvoiceNo"].ToString() + "'";
                }else
                {
                    IQuery = "Update PurInvMaster set VoucherNo ='" + strAutoCode + "' , VoucherFlag = 'Y' " +
                                             "Where DealerCode='" + Session["DealerCode"].ToString() + "' and PurInvNo ='" + ViewState["InvoiceNo"].ToString() + "'";
                }

                if (sysfun.ExecuteQuery_NonQuery(IQuery))
                {
                    sysfun.UserMsg(lblMsg, Color.Green, "Voucher Generated");
                }
            }
            catch (Exception ex) { throw ex; }
        }

        public string GetNewVoucherNo(string sTableName, string sColumn, int NoOfChar)
        {

            string CCon = CConnection.GetConnStringForAccount();

            
            //#GET MAX ID FROM TABLE
            string sQuery = "SELECT MAX(" + sColumn + ") MAXID FROM " + sTableName +" where CompCode = '"+Session["DealerCode"].ToString() +"'";

            SqlDataReader drItemVal = SqlHelper.ExecuteReader(CCon, CommandType.Text, sQuery);

            //SqlDataReader drItemVal = null;
            string sNewVersion = "0";
            int iNewVersion;
            string date = DateTime.Parse(DateTime.Now.ToShortDateString()).ToString("yyyy-MM-dd");
            string subDate = date.Substring(2);
            try
                {
                    if (drItemVal.HasRows)
                    {
                        drItemVal.Read();
                        sNewVersion = myFunc.GetNullString(drItemVal["MAXID"]);
                        drItemVal.Close();                        

                        if (sNewVersion == "")
                        {
                            sNewVersion = "0";
                            iNewVersion = Convert.ToInt32(sNewVersion) + 1;
                            sNewVersion = Convert.ToString(iNewVersion).PadLeft(NoOfChar, '0');
                        }
                        else
                        {
                            string sub = sNewVersion.Substring(12);
                            iNewVersion = Convert.ToInt32(sub) + 1;
                            sNewVersion = Convert.ToString(iNewVersion).PadLeft(NoOfChar, '0');
                        }
                        return "JV-" + subDate +"-"+ sNewVersion;

                    }
                    else
                    {
                        iNewVersion = 0;
                        sNewVersion = Convert.ToString(iNewVersion).PadLeft(NoOfChar, '0');
                        return "JV-" + subDate + "-" + sNewVersion;
                }

                }
                catch (Exception ex)
                {
                    //ShowError();
                    drItemVal.Close();
                }

            return sNewVersion;
        }

        private void LoadJVGrid(string CusInv)
        {
            SqlParameter[] dsParamInv = {
                new SqlParameter("@DealerCode",SqlDbType.Char,5),
                new SqlParameter("@InvoiceNo",SqlDbType.Char,8)
            };

            dsParamInv[0].Value = Session["DealerCode"].ToString();
            dsParamInv[1].Value = CusInv;

            totCredit = totDebit = 0;

            DataSet dsCustomerInvoice = new DataSet();
            dsCustomerInvoice = myFunc.FillDataSet("sp_W2_CustomerInvoice_JV", dsParamInv);


            if(dsCustomerInvoice == null)
            {
                return;
            }else
            if (dsCustomerInvoice.Tables[0].Rows.Count > 0)
            {
                string AccountCode = dsCustomerInvoice.Tables[0].Rows[0]["AccountCode"].ToString();
                string Customer = dsCustomerInvoice.Tables[0].Rows[0]["CusDesc"].ToString().Trim();
                double GrossAmount  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["GrossAmount"]) ;
                double GSTAmount  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["GSTAmount"]) ;
                double PSTAmount  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["SSTAmount"]) ;
                double SubTotal  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["SubTotal"] ) ;
                double DiscLabor  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["DiscountAmount"] ) ;
                double TotalAmtCustomer  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["NetAmountCustomer"] ) ;
                double DiscountParts  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PartsDiscount"]);
                double JobsTotal  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["JobsTotal"]);
                double LubTotal  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LubPartsTotal"]) ;
                double PartsTotal  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PartsTotal"]) ;
                double SubletTotal  =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["SubletTotal"]) ;
                double pCkd =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PC.K.D"]) ;
                double pLocal =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PLocal"]) ;
                double pMarket =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["PMarket"]) ;
                double lCkd =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LC.K.D"]) ;
                double lLocal =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LLocal"]) ;
                double lMarket =  Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["LMarket"]) ;
                double Sublet = Convert.ToDouble(dsCustomerInvoice.Tables[0].Rows[0]["Sublet"]);

                string Naration = "Jobcard : " + dsCustomerInvoice.Tables[0].Rows[0]["JobCardCode"].ToString().Trim() + " | " +
                                  "Invoice : " + dsCustomerInvoice.Tables[0].Rows[0]["InvoiceNo"].ToString().Trim() + " | " +
                                  "Customer : " + dsCustomerInvoice.Tables[0].Rows[0]["CusDesc"].ToString().Trim();

                double discount = DiscountParts + DiscLabor;

                if(dsCustomerInvoice.Tables[0].Rows[0]["VoucherNo"].ToString().Trim() != "")
                {
                    lblText.Text = "Edit Mode";
                    txtVoucherNo.Text = dsCustomerInvoice.Tables[0].Rows[0]["VoucherNo"].ToString().Trim();
                }

                ds = new DataSet();

                ds.Tables.Add();

                ds.Tables[0].Columns.Add(new DataColumn("AccountCode", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("AccountTitle", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Debit", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Credit", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Naration", typeof(string)));

                Session["JV"] = ds;

                if (TotalAmtCustomer > 0)
                {
                    AddCustomerDebitAmount(TotalAmtCustomer, AccountCode,Customer,Naration);
                }

                if (JobsTotal > 0)
                {
                    string code = GetAccountCode("LabourIncome");
                    AddCreditAmount(JobsTotal, code, Naration);
                }

                if (PSTAmount > 0)
                {
                    string code = GetAccountCode("PSTAccount");
                    AddCreditAmount(PSTAmount, code, Naration);
                }

                if (GSTAmount > 0)
                {
                    string code = GetAccountCode("GSTAccount");
                    AddCreditAmount(GSTAmount, code, Naration);
                }

                if (pCkd > 0)
                {
                    string code = GetAccountCode("PartsSaleIncome(CKD)");
                    AddCreditAmount(pCkd, code, Naration);
                }
                if (pLocal > 0)
                {
                    string code = GetAccountCode("PartsSaleIncome(Local)");
                    AddCreditAmount(pLocal,code, Naration);
                }
                if (pMarket > 0)
                {
                    string code = GetAccountCode("PartsSaleIncome(Market)");
                    AddCreditAmount(pMarket, code, Naration);
                }

                if (lLocal > 0)
                {
                    string code = GetAccountCode("LubricnatSaleIncome(Local)");
                    AddCreditAmount(lLocal, code, Naration);
                }
                if (lMarket > 0)
                {
                    string code = GetAccountCode("LubricnatSaleIncome(Market)");
                    AddCreditAmount(lMarket,code, Naration);
                }

                if (SubletTotal > 0)
                {
                    string code = GetAccountCode("SubletIncome");
                    AddCreditAmount(SubletTotal, code, Naration);
                }
                if (discount > 0)
                {
                    string code = GetAccountCode("CashDiscountTaken");
                    AddDebitAmount(discount, code, Naration);
                }
            }
        }

        private void LoadPIGrid(string CusInv)
        {
            SqlParameter[] dsParamInv = {
                new SqlParameter("@DealerCode",SqlDbType.Char,5),
                new SqlParameter("@ReceiptNo",SqlDbType.Char,8)
            };

            dsParamInv[0].Value = Session["DealerCode"].ToString();
            dsParamInv[1].Value = CusInv;

            totCredit = totDebit = 0;


            DataSet ds = new DataSet();
            ds = myFunc.FillDataSet("sp_W2_PayableInvoice_GL", dsParamInv);

            if (ds.Tables[0].Rows.Count > 0)
            {
                string AccountCode = ds.Tables[0].Rows[0]["AccountCode"].ToString();
                string  VendorDesc = ds.Tables[0].Rows[0]["VendorDesc"].ToString();
                double TotalAmtCustomer = Convert.ToDouble(ds.Tables[0].Rows[0]["TotalIncTax"]);

                double FurTaxTotal = Convert.ToDouble(ds.Tables[0].Rows[0]["FurTaxTotal"]);
                double ExTaxTotal = Convert.ToDouble(ds.Tables[0].Rows[0]["ExTaxTotal"]);
                double GSTTotal = Convert.ToDouble(ds.Tables[0].Rows[0]["GSTTotal"]);
                double DiscountAmt = Convert.ToDouble(ds.Tables[0].Rows[0]["DiscountAmt"]);
                //double WHT20 = Convert.ToDouble(ds.Tables[0].Rows[0]["WHT20%"]);
                //double OtherCharges = Convert.ToDouble(ds.Tables[0].Rows[0]["OtherCharges"]);
                double pCkd = Convert.ToDouble(ds.Tables[0].Rows[0]["PC.K.D"]);
                double pLocal = Convert.ToDouble(ds.Tables[0].Rows[0]["PLocal"]);
                double pMarket = Convert.ToDouble(ds.Tables[0].Rows[0]["PMarket"]);
                double lCkd = Convert.ToDouble(ds.Tables[0].Rows[0]["LC.K.D"]);
                double lLocal = Convert.ToDouble(ds.Tables[0].Rows[0]["LLocal"]);
                double lMarket = Convert.ToDouble(ds.Tables[0].Rows[0]["LMarket"]);
                

                string Naration = "Invoice : " + ds.Tables[0].Rows[0]["PurInvNo"].ToString().Trim() + " | " +
                    "GRN No : " + ds.Tables[0].Rows[0]["GRNNo"].ToString().Trim() + " | " +
                    "Order No : " + ds.Tables[0].Rows[0]["OrderNo"].ToString().Trim() + " | " +
                                  "Vendor : " + ds.Tables[0].Rows[0]["VendorDesc"].ToString().Trim();


                if (ds.Tables[0].Rows[0]["VoucherNo"].ToString().Trim() != "")
                {
                    lblText.Text = "Edit Mode";
                    txtVoucherNo.Text = ds.Tables[0].Rows[0]["VoucherNo"].ToString().Trim();
                }

                ds = new DataSet();

                ds.Tables.Add();

                ds.Tables[0].Columns.Add(new DataColumn("AccountCode", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("AccountTitle", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Debit", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Credit", typeof(string)));
                ds.Tables[0].Columns.Add(new DataColumn("Naration", typeof(string)));

                Session["JV"] = ds;

                
                if (TotalAmtCustomer > 0)
                {
                    AddCustomerAmount(TotalAmtCustomer, AccountCode, VendorDesc, Naration);
                }
                if (DiscountAmt > 0)
                {
                    string code = GetAccountCode("CashDiscountTaken");
                    AddCreditAmount(DiscountAmt, code, Naration);
                }

                if (GSTTotal > 0)
                {
                    string code = GetAccountCode("GSTAccount");
                    AddDebitAmount(GSTTotal, code, Naration);
                }

                if (FurTaxTotal > 0)
                {
                    string code = GetAccountCode("FurthurAccount");
                    AddDebitAmount(FurTaxTotal,code, Naration);
                }

                if (ExTaxTotal > 0)
                {
                    string code = GetAccountCode("OtherTax");
                    AddDebitAmount(ExTaxTotal, code, Naration);
                }


                if (pCkd > 0)
                {
                    string code = GetAccountCode("PartsStock(CKD)");
                    AddDebitAmount(pCkd, code, Naration);
                }
                if (pLocal > 0)
                {
                    string code = GetAccountCode("PartsStock(Local)");
                    AddDebitAmount(pLocal, code, Naration);
                }
                if (pMarket > 0)
                {
                    string code = GetAccountCode("PartsStock(Market)");
                    AddDebitAmount(pMarket, code, Naration);
                }

                if (lLocal > 0)
                {
                    string code = GetAccountCode("LubricnatStock(Local)");
                    AddDebitAmount(lLocal, code, Naration);
                }
                if (lMarket > 0)
                {
                    string code = GetAccountCode("LubricnatSstock(Market)");
                    AddDebitAmount(lMarket, code, Naration);
                }

               
            }
        }


        private void AddCustomerDebitAmount(double amount, string code, string Customer, string Naration)
        {
            ds = (DataSet)Session["JV"];

            DataRow dr = ds.Tables[0].NewRow();
            dr["AccountCode"] = code;
            dr["AccountTitle"] = Customer;
            dr["Debit"] = amount;
            dr["Credit"] = "0.0";
            dr["Naration"] = Naration;

            totDebit = totDebit + amount;

            ds.Tables[0].Rows.Add(dr);

            gvJV.DataSource = ds.Tables[0];
            gvJV.DataBind();

            Session["JV"] = ds;
        }
        private void AddCustomerAmount(double amount, string code, string Customer,string Naration)
        {
            ds = (DataSet)Session["JV"];

            DataRow dr = ds.Tables[0].NewRow();
            dr["AccountCode"] = code;
            dr["AccountTitle"] = Customer;
            dr["Debit"] = "0.0";
            dr["Credit"] = amount;
            dr["Naration"] = Naration;

            totCredit = totCredit + amount;

            ds.Tables[0].Rows.Add(dr);

            gvJV.DataSource = ds.Tables[0];
            gvJV.DataBind();

            Session["JV"] = ds;
        }
        private void AddCreditAmount(double amount, string code , string Naration)
        {
            ds = (DataSet)Session["JV"];
            
            DataRow dr = ds.Tables[0].NewRow();
            dr["AccountCode"] = code;
            dr["AccountTitle"] = GetAccounttitle(code);
            dr["Debit"] = "0.0";
            dr["Credit"] = amount;
            dr["Naration"] = Naration;

            totCredit = totCredit + amount;

            ds.Tables[0].Rows.Add(dr);

            gvJV.DataSource = ds.Tables[0];
            gvJV.DataBind();

            Session["JV"] = ds;
        }
        private void AddDebitAmount(double amount , string account , string Naration)
        {
            ds = (DataSet)Session["JV"];

            DataRow dr = ds.Tables[0].NewRow();

            dr["AccountCode"] = account;
            dr["AccountTitle"] = GetAccounttitle(account);
            dr["Debit"] = amount;
            dr["Credit"] = "0.0";
            dr["Naration"] = Naration;
            totDebit = totDebit + amount;

            ds.Tables[0].Rows.Add(dr);

            gvJV.DataSource = ds.Tables[0];
            gvJV.DataBind();

            Session["JV"] = ds;
        }

    }
}