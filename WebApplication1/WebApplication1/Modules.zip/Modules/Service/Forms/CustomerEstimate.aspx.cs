﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using CrystalDecisions.CrystalReports.Engine;
using Microsoft.ApplicationBlocks.Data;
using CrystalDecisions.Shared;
using CConn;
using DXBMS.Data;
using System.Threading;

namespace DXBMS.Modules.Service
{
    public partial class CustomerEstimate : System.Web.UI.Page
    {
        MainBLL objMBLL = new MainBLL();
        SysFunctions SysFunc = new SysFunctions();
        Transaction ObjTrans = new Transaction();
        SqlTransaction Trans;
        //string apStr;
        bool search_result, search_item;
        DataTable JobDT, LubDT,  PartsDT;
        DataSet dsJobCardDetail, dsJobCardParts, dsJobCardLub;
        double totLabour, totParts, totlub;
        int  countLabour, countParts, countlub, countlubRecQty, countPartsRecQty;
        //decimal deductAmount;
        clsLookUp clslook = new clsLookUp();
        string CustomerEstimateCode;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Session["UserName"] == null)
            {
                Response.Redirect("~/login.aspx");

            }
            
            if (ViewState["Parts"] != null) PartsDT = (DataTable)ViewState["Parts"];
            if (ViewState["Job"] != null) JobDT = (DataTable)ViewState["Job"];
            if (ViewState["Lub"] != null) LubDT = (DataTable)ViewState["Lub"];

            if (Page.IsPostBack)
            {

                if (!string.IsNullOrEmpty(Session["LookUpData"].ToString()))
                {
                    SelectedPartDetail(Session["LookUpData"].ToString());
                }
            }

            if (!IsPostBack)
            {
                
                    ThreadStart childthreat = new ThreadStart(childthreadcall);
                    Thread child = new Thread(childthreat);

                    child.Start();
                           

                setInitialDates();
                createJobDT();               //-----------------------------------JobCardDetail
                createLubDT();              //------------------------------------------PARTS            
                createPartsDT();            //-----------------------------------------JOB

                lblBranch.Visible = false;
                lblInsuranceComp.Visible = false;
                lblBranch.Visible = false;
                lblConveyer.Visible = false;
                ddlInsuranceComp.Visible = false;
                ddlInsBranch.Visible = false;
                txtConvyer.Visible = false;



                DataSet ds = new DataSet();
                DataSet ds_Schedule = new DataSet();
                SqlParameter[] JobCardMaster_param = {                                            
                new SqlParameter("@DealerCode",SqlDbType.Char,5)};
                JobCardMaster_param[0].Value = Session["DealerCode"].ToString();
                //Fill Advisor Drop Down List
                objMBLL.FillDrp_SP(ddlAdvisor, "sp_Get_Advisor", "EmpCode", "EmpName", JobCardMaster_param, true, "--Select--", false, "");
                //Fill Insurance company Drop Down List
                objMBLL.FillDrp_SP(ddlInsuranceComp, "sp_2W_GetAllInsuranceCompany", "InsCompCode", "InsCompDescription", null, true, "--Select--", false, "");
                //Fill Insurance Branch Drop Down List
                objMBLL.FillDrp_SP(ddlInsBranch, "sp_2W_GetAllBranch", "BranchCode", "BranchDesc", null, true, "--Select--", false, "");
                //Fill CustomerEstimateCode Drop Down List
                //SysFunc.GetCustEstMultiColumnsDDL(ddlEstCode);
                Load_CustEstMultiColumnsDDL();
                //Fill RegNo Drop Down List
                string[] Columns = new string[] { "RegNo", "EngineNo", "ChassisNo" };
                SysFunc.GetMultiColumnsDDL(ddlRegNo, Columns, "CustomerVehicle", "DealerCode ='" + Session["DealerCode"].ToString() + "' ", "RegNo",string.Empty,false,false);

                //Fill Parts Drop Down List
                Columns = new string[] { "ItemCode", "PartItemNo", "ItemDesc", "Source" };
                //SysFunc.GetMultiColumnsDDL(ddlParts, Columns, "Item", "DealerCode ='" + Session["DealerCode"].ToString() + "' And LubeFlag = 'N' ", "ItemCode", "Order by ItemDesc",false,false);
                //Fill Lubricates Drop Down List
                SysFunc.GetMultiColumnsDDL(ddllLubs, Columns, "Item", "DealerCode ='" + Session["DealerCode"].ToString() + "' And LubeFlag = 'Y' ", "ItemCode","Order by ItemDesc" , false,false);
                SysFunc.ExecuteQuery("SELECT (DJ.DefJobDesc) ColName, DJ.DefJobCode ColValue FROM DefaultJob DJ LEFT OUTER JOIN JobCategory JC ON DJ.DealerCode = JC.DealerCode And DJ.JobCatCode = JC.JobCatCode Where DJ.DealerCode = '"+Session["DealerCode"].ToString()+"'", ref ds);
                
                ddlJobs.DataSource = ds.Tables[0];
                ddlJobs.DataTextField = "ColName";
                ddlJobs.DataValueField = "ColValue";
                ddlJobs.DataBind();
            }
            Session["LookUpData"] = string.Empty;
        }
        private void Load_CustEstMultiColumnsDDL()
        {
            string[] Columns = new string[] { "CustomerEstimateCode", "Convert(Varchar(10),tdDate,105)", "RegNo", "UserName" };
            SysFunc.GetMultiColumnsDDL(ddlEstCode, Columns, "CustomerEstimateMaster", "DealerCode ='" + Session["DealerCode"].ToString() + "'  And DelFlag='N' ", "CustomerEstimateCode", string.Empty, false, false);

        }
        protected void LoadMasterData()
        {
            SqlParameter[] dsParam = {                                                       
                                    new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                    new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8)
                                 };
            dsParam[0].Value = Session["DealerCode"].ToString();
            dsParam[1].Value = ddlEstCode.SelectedValue.ToString ();
            

            DataSet dsJobCardMaster = new DataSet();
            dsJobCardMaster = SysFunc.FillDataSet("sp_2W_CustomerEstimateMaster_Select", dsParam);

            setVehcileInfo(dsJobCardMaster);
            setJobCardInfo(dsJobCardMaster);

            if (ddlJobCardType.SelectedValue == "Insurance")
            {
                txtDep.ReadOnly = false;
                txtDep.Text = "0";
            }
            else
            {
                txtDep.ReadOnly = true;
                txtDep.Text = "";
            }           


            dsJobCardDetail = new DataSet();
            dsJobCardDetail = SysFunc.FillDataSet("sp_2W_CustomerEstimate_Detail_Select", dsParam);
            //if (dsJobCardDetail.Tables[0].Rows.Count == 0) dsJobCardDetail.Tables[0].Rows.Add(dsJobCardDetail.Tables[0].NewRow());
            ViewState["Job"] = dsJobCardDetail.Tables[0]; gvJobCard.DataSource = dsJobCardDetail; gvJobCard.DataBind();

            dsJobCardParts = new DataSet();
            dsJobCardParts = SysFunc.FillDataSet("sp_2W_CustomerEstimate_PartsDetail_Select", dsParam);
            //if (dsJobCardParts.Tables[0].Rows.Count == 0) dsJobCardParts.Tables[0].Rows.Add(dsJobCardParts.Tables[0].NewRow());
            ViewState["Parts"] = dsJobCardParts.Tables[0]; gvJobCardParts.DataSource = dsJobCardParts; gvJobCardParts.DataBind();

            dsJobCardLub = new DataSet();
            dsJobCardLub = SysFunc.FillDataSet("sp_2W_CustomerEstimate_LubricanteDetail_Select", dsParam);
            //if (dsJobCardLub.Tables[0].Rows.Count == 0) dsJobCardLub.Tables[0].Rows.Add(dsJobCardLub.Tables[0].NewRow());
            ViewState["Lub"] = dsJobCardLub.Tables[0]; gvLubParts.DataSource = dsJobCardLub; gvLubParts.DataBind();
        }

        private void setInitialDates()
        {
            txtCreateDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        }



        protected void LoadVehInfo()
        {
            DataSet dsVehInfo = new DataSet();
            SqlParameter[] param = {                                 
                                    new SqlParameter("@DealerCode",SqlDbType.VarChar,5), 
                                    new SqlParameter("@RegNo",SqlDbType.VarChar,30)
                               };
            param[0].Value = Session["DealerCode"];
            param[1].Value = ddlRegNo.SelectedValue .ToString ().Trim();
            dsVehInfo = SysFunc.FillDataSet("sp_W2_CustomerVehicle_Select", param);
            if (dsVehInfo.Tables[0].Rows.Count > 0) setVehcileInfo(dsVehInfo);
        }

        private void setVehcileInfo(DataSet dsJobCardMaster)
        {
            ddlRegNo.SelectedValue = dsJobCardMaster.Tables[0].Rows[0]["RegNo"].ToString().Trim();
            txtChassisNo.Text = dsJobCardMaster.Tables[0].Rows[0]["ChassisNo"].ToString();
            txtEngineNo.Text = dsJobCardMaster.Tables[0].Rows[0]["EngineNo"].ToString();
            txtCustomer.Text = dsJobCardMaster.Tables[0].Rows[0]["CusCode"].ToString();
            txtCustomerDesc.Text = dsJobCardMaster.Tables[0].Rows[0]["CusDesc"].ToString();
            if (dsJobCardMaster.Tables[0].Columns.Contains("CustomerEstimateCode"))
            {
                txtEndUser.Text = dsJobCardMaster.Tables[0].Rows[0]["CusCode"].ToString();
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(dsJobCardMaster.Tables[0].Rows[0]["JobsTotal"]) +
                                  Convert.ToInt32(dsJobCardMaster.Tables[0].Rows[0]["PartsTotal"]) +
                                  Convert.ToInt32(dsJobCardMaster.Tables[0].Rows[0]["LubsTotal"]));
            }
            else
            {
                txtEndUser.Text = dsJobCardMaster.Tables[0].Rows[0]["EndUserCode"].ToString(); 
            }
            txtEndUserDesc.Text = dsJobCardMaster.Tables[0].Rows[0]["EndUserDesc"].ToString();
            txtBrand.Text = dsJobCardMaster.Tables[0].Rows[0]["BrandCode"].ToString();
            txtBrandDesc.Text = dsJobCardMaster.Tables[0].Rows[0]["BrandDesc"].ToString(); 
            txtProduct.Text = dsJobCardMaster.Tables[0].Rows[0]["ProdCode"].ToString();
            txtVersion.Text = dsJobCardMaster.Tables[0].Rows[0]["VersionCode"].ToString();
            txtVersionDesc.Text = dsJobCardMaster.Tables[0].Rows[0]["ProdDesc"].ToString();
            


            string InsCompCode = dsJobCardMaster.Tables[0].Rows[0]["InsCompCode"].ToString().Trim();
            string InsBranchCode = dsJobCardMaster.Tables[0].Rows[0]["InsBranchCode"].ToString().Trim();
            if (dsJobCardMaster.Tables[0].Columns.Contains("CustomerEstimateCode"))
            {
                if (dsJobCardMaster.Tables[0].Rows[0]["InsCompCode"] != DBNull.Value)
                {
                    ddlJobCardType.SelectedIndex = 1;

                    ddlInsuranceComp.SelectedValue = dsJobCardMaster.Tables[0].Rows[0]["InsCompCode"].ToString().Trim();
                    ddlInsBranch.SelectedValue = dsJobCardMaster.Tables[0].Rows[0]["InsBranchCode"].ToString().Trim();
                    txtConvyer.Text = dsJobCardMaster.Tables[0].Rows[0]["surveyor"].ToString().Trim();
                }
                else
                {
                    ddlJobCardType.SelectedIndex = 0;
                    ddlInsuranceComp.SelectedIndex = 0;
                    ddlInsBranch.SelectedIndex = 0;
                    txtConvyer.Text = string .Empty ;
                }
                ddlAdvisor.SelectedValue = dsJobCardMaster.Tables[0].Rows[0]["TechCode"].ToString().Trim();
                ddlJobCardType_SelectedIndexChanged(ddlJobCardType, null);
            }

            //Load Schedual Data in DDL

            SqlParameter[] param_Schedule = {                                                       
                                                                new SqlParameter("@ProdCode",SqlDbType.VarChar,10),
                                                                new SqlParameter("@VersionCode",SqlDbType.Char,3)
                                                              };
            param_Schedule[0].Value = txtProduct.Text.Trim();
            param_Schedule[1].Value = txtVersion.Text.Trim();
            objMBLL.FillDrp_SP(ddlSchedule, "sp_2W_MaintainenceSchedule_Select", "KM", "KM", param_Schedule, true, "--Select--", false, "");
        }

        public void childthreadcall()
        {
            try
            {
                DataSet ds = new DataSet();
                string sQuery = "SP_SelectParts '" + Session["DealerCode"].ToString() + "', 'P'";

                if (SysFunc.ExecuteQuery(sQuery, ref ds))
                {
                    Session["Parts"] = ds;
                    
                }

            }
            catch (ThreadAbortException e)
            {

                //lblmessage.Text += "<br /> child thread - exception";

            }
            finally
            {
                //lblmessage.Text += "<br /> child thread - unable to catch the  exception";
            }
        }

        private void setJobCardInfo(DataSet dsJobCardMaster)
        {
            if (txtEstCode.Text.Trim().Length != 0)
            {
                //lblJobCardTotal.Text = dsJobCardMaster.Tables[0].Rows[0]["JobsTotal"].ToString();
                //txtPartsTotal.Text = dsJobCardMaster.Tables[0].Rows[0]["PartsTotal"].ToString();
                //txtLubTotal.Text = dsJobCardMaster.Tables[0].Rows[0]["LubsTotal"].ToString();
                string TechCode = dsJobCardMaster.Tables[0].Rows[0]["TechCode"].ToString().Trim();
                ddlAdvisor.SelectedItem.Text = dsJobCardMaster.Tables[0].Rows[0]["EmpName"].ToString().Trim();


                string InsCompCode = dsJobCardMaster.Tables[0].Rows[0]["InsCompCode"].ToString().Trim();
                string InsBranchCode = dsJobCardMaster.Tables[0].Rows[0]["InsBranchCode"].ToString().Trim();
                if (dsJobCardMaster.Tables[0].Rows[0]["InsCompCode"] == DBNull.Value)
                {
                    ddlInsuranceComp.SelectedIndex = 0;
                }
                else
                {
                    ddlInsuranceComp.SelectedItem.Text = dsJobCardMaster.Tables[0].Rows[0]["InsCompDescription"].ToString();
                }
                if (dsJobCardMaster.Tables[0].Rows[0]["InsBranchCode"] == DBNull.Value)
                {
                    ddlInsBranch.SelectedIndex = 0;
                }
                else
                {
                    ddlInsBranch.SelectedItem.Text = dsJobCardMaster.Tables[0].Rows[0]["BranchDesc"].ToString();
                }
                if (dsJobCardMaster.Tables[0].Rows[0]["surveyor"] == DBNull.Value)
                {
                    txtConvyer.Text = "";
                }
                else
                {
                    txtConvyer.Text = dsJobCardMaster.Tables[0].Rows[0]["surveyor"].ToString().Trim();
                }

                if (dsJobCardMaster.Tables[0].Rows[0]["Schedule"].ToString() == "--Select")
                {
                    SqlParameter[] param_Schedule = {                                                       
                                                                new SqlParameter("@ProdCode",SqlDbType.VarChar,10),
                                                                new SqlParameter("@VersionCode",SqlDbType.Char,3)
                                                              };
                    param_Schedule[0].Value = txtProduct.Text.Trim();
                    param_Schedule[1].Value = txtVersion.Text.Trim();
                    objMBLL.FillDrp_SP(ddlSchedule, "sp_2W_MaintainenceSchedule_Select", "KM", "KM", param_Schedule, true, "--Select--", false, "");
                }
                else
                {
                    ddlSchedule.SelectedValue = dsJobCardMaster.Tables[0].Rows[0]["Schedule"].ToString().Trim();
                }
                txtRemarks.Text = dsJobCardMaster.Tables[0].Rows[0]["Remarks"].ToString().Trim();
                SysFunc = new SysFunctions ();
            }
        }

        private void createJobDT()
        {
            JobDT = new DataTable();
            JobDT.Columns.Add(new DataColumn("ID", typeof(int)));
            JobDT.Columns.Add(new DataColumn("JobCode", typeof(string)));
            JobDT.Columns.Add(new DataColumn("DefJobDesc", typeof(string)));
            JobDT.Columns.Add(new DataColumn("JobRemarks", typeof(string)));
            JobDT.Columns.Add(new DataColumn("Amount", typeof(string)));
            JobDT.Columns.Add(new DataColumn("Type", typeof(string)));
            gvJobCard.DataSource = JobDT; gvJobCard.DataBind(); ViewState["Job"] = JobDT;
        }

        private void createLubDT()
        {
            LubDT = new DataTable();
            LubDT.Columns.Add(new DataColumn("ID", typeof(int)));
            LubDT.Columns.Add(new DataColumn("PartNo", typeof(string)));
            LubDT.Columns.Add(new DataColumn("PartsDesc", typeof(string)));
            LubDT.Columns.Add(new DataColumn("Qty", typeof(string)));
            LubDT.Columns.Add(new DataColumn("Price", typeof(string)));
            LubDT.Columns.Add(new DataColumn("Total", typeof(string)));
            LubDT.Columns.Add(new DataColumn("ItemCode", typeof(string)));
            gvLubParts.DataSource = LubDT; gvLubParts.DataBind(); ViewState["Lub"] = LubDT;
        }

        private void createPartsDT()
        {
            PartsDT = new DataTable();
            PartsDT.Columns.Add(new DataColumn("ID", typeof(int)));
            PartsDT.Columns.Add(new DataColumn("PartNo", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("PartsDesc", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("Dep", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("DepAmount", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("Qty", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("Price", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("Total", typeof(string)));
            PartsDT.Columns.Add(new DataColumn("ItemCode", typeof(string)));                       
            gvJobCardParts.DataSource = PartsDT; gvJobCardParts.DataBind(); ViewState["Parts"] = PartsDT;
        }



        protected void btnSave_Click(object sender, EventArgs e)
        {
            int GVJobCard = gvJobCard.Rows.Count;
            int GVParts = gvJobCardParts.Rows.Count;
            int GVLub = gvLubParts.Rows.Count;

            if (Convert.ToDateTime(SysFunc.SaveDate(txtCreateDate.Text)).Date > Convert.ToDateTime(DateTime.Now.Date.ToString("yyyy-MM-dd")).Date)
            //if (Convert.ToDateTime(txtCreateDate.Text).Date > Convert.ToDateTime(DateTime.Now.Date.ToString("yyyy-MM-dd")).Date)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Date should not greater then current date");
                return;
            }

            TextBox[] textBoxes = {  txtCustomer, txtEndUser, txtBrand, txtProduct, txtVersion ,
                                    txtChassisNo, txtEngineNo};
            if (!MasterValidation(textBoxes)) return;

            
            if (ddlRegNo.SelectedItem.Text == "Select")
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Error: RegNo should not be left blank");
                return;
            }
            if (ddlAdvisor.SelectedItem.Text == "--Select--")
            {
                SetFocus(ddlAdvisor);
                SysFunc.UserMsg(lblMsg,Color.Red, "Error: Advisor should not left Blank...");

            }
            else
            {
                if (GVJobCard > 0 | GVParts > 0 | GVLub > 0)
                {
                    CustomerEsTimate_Entry();
                    string[] Columns = new string[] { "CustomerEstimateCode", "RegNo", "UserName" };
                    SysFunc.GetMultiColumnsDDL(ddlEstCode, Columns, "CustomerEstimateMaster", "DealerCode ='" + Session["DealerCode"].ToString() + "'  And DelFlag='N'", "CustomerEstimateCode", "Order by CustomerEstimateCode Desc",false,false);
                }
                else
                {
                    
                    SysFunc.UserMsg(lblMsg, Color.Red, "One of the detail must be selected !!!", txtQuantity);
                    return;
                }
            }
        }

        private void CustomerEsTimate_Entry()
        {
            SqlParameter[] CustomerEstimate_param = {                                            
           /*0*/ new SqlParameter("@DealerCode",SqlDbType.Char,5),
           /*1*/ new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8),
           /*2*/ new SqlParameter("@tdDate",SqlDbType.DateTime),
           /*3*/ new SqlParameter("@CusCode",SqlDbType.Char,8),
           /*4*/ new SqlParameter("@UserName",SqlDbType.Char,100),
           /*5*/ new SqlParameter("@BrandCode",SqlDbType.VarChar,15),
           /*6*/ new SqlParameter("@RegNo",SqlDbType.VarChar,25),
           /*7*/ new SqlParameter("@EngineNo",SqlDbType.VarChar,30),
           /*8*/ new SqlParameter("@ChassisNo",SqlDbType.VarChar,30),
           /*9*/ new SqlParameter("@ProdCode",SqlDbType.VarChar,15),
           /*10*/ new SqlParameter("@VersionCode",SqlDbType.Char,3),
           /*11*/ new SqlParameter("@JobsTotal",SqlDbType.Float),
           /*12*/ new SqlParameter("@PartsTotal",SqlDbType.Float),
           /*13*/ new SqlParameter("@LubsTotal",SqlDbType.Float),           
           /*14*/ new SqlParameter("@Remarks",SqlDbType.VarChar,50),
           /*15*/ new SqlParameter("@TechCode",SqlDbType.Char,3),
           /*16*/ new SqlParameter("@DelFlag",SqlDbType.Char,1),
           /*17*/ new SqlParameter("@UpdUser",SqlDbType.Char,50),
           /*18*/ new SqlParameter("@UpdDate",SqlDbType.DateTime),
           /*19*/ new SqlParameter("@UpdTime",SqlDbType.DateTime),
           /*20*/ new SqlParameter("@UpdTerm",SqlDbType.Char,50),
           /*21*/ new SqlParameter("@Schedule",SqlDbType.Char,8),
           /*22*/ new SqlParameter("@TransferStatus",SqlDbType.Char,1),
           /*23*/ new SqlParameter("@InsCompCode",SqlDbType.Char,4),
           /*24*/ new SqlParameter("@InsBranchCode",SqlDbType.Char,4),
           /*25*/ new SqlParameter("@surveyor",SqlDbType.VarChar,100)
           

                                                };
            CustomerEstimate_param[0].Value = Session["DealerCode"].ToString();
            //Auto Code Generation Decision on Insert 
            //for update CustomerEstimate
            
            Label lblFooterAmount =new Label();
            Label lblFooterPartAmount = new Label();
            Label lblFooterLubsAmount = new Label();
            if (gvJobCard.Rows.Count > 0) lblFooterAmount = (Label)gvJobCard.FooterRow.FindControl("lblFooterAmount"); else lblFooterAmount.Text = "0";

            if (gvJobCardParts.Rows.Count > 0) lblFooterPartAmount = (Label)gvJobCardParts.FooterRow.FindControl("lblFooterPartAmount"); else lblFooterPartAmount.Text = "0";
            if (gvLubParts.Rows.Count > 0) lblFooterLubsAmount = (Label)gvLubParts.FooterRow.FindControl("lblFooterLubsAmount"); else lblFooterLubsAmount.Text  ="0";
            if (ddlEstCode.SelectedIndex==0)
            {

                CustomerEstimateCode = SysFunc.AutoGen("CustomerEstimateMaster", "CustomerEstimateCode", DateTime.Parse(DateTime.Now.ToShortDateString()).ToString("dd/MM/yyyy"));
                CustomerEstimate_param[1].Value = CustomerEstimateCode;
                CustomerEstimate_param[2].Value = SysFunc.SaveDate(txtCreateDate.Text);
                CustomerEstimate_param[3].Value = txtCustomer.Text.Trim();
                CustomerEstimate_param[4].Value = txtEndUserDesc.Text;
                CustomerEstimate_param[5].Value = txtBrand.Text.Trim();
                CustomerEstimate_param[6].Value = ddlRegNo.SelectedValue.ToString().Trim().ToUpper();
                CustomerEstimate_param[7].Value = txtEngineNo.Text.Trim().ToUpper();
                CustomerEstimate_param[8].Value = txtChassisNo.Text.Trim().ToUpper();
                CustomerEstimate_param[9].Value = txtProduct.Text.Trim().ToUpper();
                CustomerEstimate_param[10].Value = txtVersion.Text.Trim().ToUpper();
                CustomerEstimate_param[11].Value = lblFooterAmount.Text.Trim();
                CustomerEstimate_param[12].Value = lblFooterPartAmount.Text.Trim();
                CustomerEstimate_param[13].Value = lblFooterLubsAmount.Text.Trim();
                CustomerEstimate_param[14].Value = txtRemarks.Text.Trim().ToUpper();
                CustomerEstimate_param[15].Value = ddlAdvisor.SelectedValue.ToString().Trim();
                CustomerEstimate_param[16].Value = "N";
                CustomerEstimate_param[17].Value = Session["UserName"].ToString();
                CustomerEstimate_param[18].Value = DateTime.Now;
                CustomerEstimate_param[19].Value = SysFunc.SaveTime(DateTime.Now.ToString("HH:mm"));
                CustomerEstimate_param[20].Value = GlobalVar.mUserIPAddress;
                if (ddlSchedule.SelectedItem.Text == "--Select--") CustomerEstimate_param[21].Value = ddlSchedule.SelectedValue.ToString();
                else CustomerEstimate_param[21].Value = DBNull.Value;
                CustomerEstimate_param[22].Value = "E";

                if (ddlJobCardType.SelectedValue == "Insurance")
                {
                    CustomerEstimate_param[23].Value = ddlInsuranceComp.SelectedValue.ToString();
                    CustomerEstimate_param[24].Value = ddlInsBranch.SelectedValue.ToString();
                    CustomerEstimate_param[25].Value = txtConvyer.Text.Trim();
                }
                else
                {
                    CustomerEstimate_param[23].Value = DBNull.Value;
                    CustomerEstimate_param[24].Value = DBNull.Value;
                    CustomerEstimate_param[25].Value = DBNull.Value;
                }
            }
            else
            {
                //txtEstCode.Text = SysFunc.AutoGen_CustomerEstimate("CustomerEstimateMaster", "CustomerEstimateCode", DateTime.Parse(DateTime.Now.ToShortDateString()).ToString("dd/MM/yyyy"));
                CustomerEstimateCode = ddlEstCode.SelectedValue.ToString().Trim();
                CustomerEstimate_param[1].Value = CustomerEstimateCode;
                CustomerEstimate_param[2].Value = SysFunc.SaveDate(txtCreateDate.Text);
                CustomerEstimate_param[3].Value = txtCustomer.Text.Trim();
                CustomerEstimate_param[4].Value = txtEndUserDesc.Text;
                CustomerEstimate_param[5].Value = txtBrand.Text.Trim();
                CustomerEstimate_param[6].Value = ddlRegNo.SelectedValue .ToString ().Trim().ToUpper();
                CustomerEstimate_param[7].Value = txtEngineNo.Text.Trim().ToUpper();
                CustomerEstimate_param[8].Value = txtChassisNo.Text.Trim().ToUpper();
                CustomerEstimate_param[9].Value = txtProduct.Text.Trim().ToUpper();
                CustomerEstimate_param[10].Value = txtVersion.Text.Trim().ToUpper();
                CustomerEstimate_param[11].Value = lblFooterAmount.Text.Trim();
                CustomerEstimate_param[12].Value = lblFooterPartAmount.Text.Trim();
                CustomerEstimate_param[13].Value = lblFooterLubsAmount.Text.Trim();
                CustomerEstimate_param[14].Value = txtRemarks.Text.Trim().ToUpper();
                CustomerEstimate_param[15].Value = ddlAdvisor.SelectedValue.ToString().Trim();
                CustomerEstimate_param[16].Value = "N";
                CustomerEstimate_param[17].Value = Session["UserName"].ToString();
                CustomerEstimate_param[18].Value = DateTime.Now;
                CustomerEstimate_param[19].Value = SysFunc.SaveTime(DateTime.Now.ToString("HH:mm"));
                CustomerEstimate_param[20].Value = GlobalVar.mUserIPAddress;
                CustomerEstimate_param[21].Value = ddlSchedule.SelectedValue.ToString();
                CustomerEstimate_param[22].Value = "E";

                if (ddlJobCardType.SelectedValue == "Insurance")
                {
                    CustomerEstimate_param[23].Value = ddlInsuranceComp.SelectedValue.ToString();
                    CustomerEstimate_param[24].Value = ddlInsBranch.SelectedValue.ToString();
                    CustomerEstimate_param[25].Value = txtConvyer.Text.Trim();
                }
                else
                {
                    CustomerEstimate_param[23].Value = DBNull.Value;
                    CustomerEstimate_param[24].Value = DBNull.Value;
                    CustomerEstimate_param[25].Value = DBNull.Value;
                }
            }
            try
            {
                if (ObjTrans.BeginTransaction(ref Trans) == true)
                {
                    //For Update CustomerEstimate
                    if (ddlEstCode.SelectedIndex ==  0)
                    {
                        if (SysFunc.ExecuteSP_NonQuery("[sp_2W_CustomerEstimate_Master_Insert]", CustomerEstimate_param, Trans))
                        {
                            //bool a = (d1 > 0 ? Inser_JobCardDetail() : false);
                            //bool a = (rowsInJobCardDetail(gvJobCard) == true ? Inser_CustomerEstimateDetail() : false);
                            if (gvJobCard.Rows.Count > 0) Inser_CustomerEstimateDetail();

                            //bool c = (d2 > 0 ? Inser_JobCardPartsDetail() : false);
                            //bool c = (rowInJobCardPartsDetail(gvJobCardParts) == true ? Inser_CustomerEstimePartsDetail() : false);
                            if(gvJobCardParts.Rows.Count > 0) Inser_CustomerEstimePartsDetail();
                            //bool d = (d3 > 0 ? Inser_JobCardLubricanteDetail() : false);
                            //bool d = (rowInJobCardLubricanteDetail(gvLubParts) == true ? Inser_CustomerEstimateLubricates_Detail() : false);
                            if (gvLubParts.Rows.Count > 0) Inser_CustomerEstimateLubricates_Detail();

                            //bool b = (d4 > 0 ? Inser_JobCardSubletDetail() : false);
                        }

                        if (ObjTrans.CommittTransaction(ref Trans) == true)
                        {

                            SysFunc.UserMsg(lblMsg, Color.Green, "Record Saved Successfully !!!");
                        }
                        else
                        {
                            ObjTrans.RollBackTransaction(ref Trans);
                            SysFunc.UserMsg(lblMsg, Color.Red, "Record nor saved Try again. Or contact to Pak Suzuki: " + txtEstCode.Text, txtEstCode);
                        }
                        clearAll();
                    }
                    else
                    {
                        //Update Customer Estimate
                        CustomerEstimate_param[1].Value = txtEstCode.Text.Trim();
                        if (SysFunc.ExecuteSP_NonQuery("[sp_Update_CustomerEstimate_Master]", CustomerEstimate_param, Trans))
                        {
                            Inser_CustomerEstimateDetail();
                            Inser_CustomerEstimePartsDetail();
                            Inser_CustomerEstimateLubricates_Detail();
                            bool c;

                        }
                        else { SysFunc.UserMsg(lblMsg,Color.Red,"Update failed"); }

                        
                        if (ObjTrans.CommittTransaction(ref Trans) == true)
                        {
                            clearAll();
                            
                            SysFunc.UserMsg(lblMsg, Color.Green, "Record Saved Successfully: " + txtEstCode.Text, txtEstCode);
                        }
                        else
                        {
                            ObjTrans.RollBackTransaction(ref Trans);
                            SysFunc.UserMsg(lblMsg, Color.Red, "Record not saved Try again. Or contact to Pak Suzuki: " + txtEstCode.Text, txtEstCode);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Error: " + ex.Message, txtEstCode);
                ObjTrans.RollBackTransaction(ref Trans);
            }


        }

        private bool Inser_CustomerEstimateDetail()
        {
            try
            {
                bool flag = false;
                SqlParameter[] Inser_CustomerEstimate_Delete_param = {                                                       
                                                                new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                                                new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8)
                                                            };
                Inser_CustomerEstimate_Delete_param[0].Value = Session["DealerCode"].ToString();
                Inser_CustomerEstimate_Delete_param[1].Value = CustomerEstimateCode.Trim();
                SqlParameter[] JobCardDetail_Insert_param = {                                                       
                                                                new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                                                new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8),
                                                                new SqlParameter("@JobCode",SqlDbType.VarChar,8),
                                                                new SqlParameter("@JobRemarks",SqlDbType.VarChar,200),
                                                                new SqlParameter("@Amount",SqlDbType.Float)                                                                
                                                            };
                if (SysFunc.ExecuteSP_NonQuery("sp_W2_CustomerEstimate_Detail_Delete", Inser_CustomerEstimate_Delete_param, Trans))
                {
                    JobDT = (DataTable)ViewState["Job"];
                    DataRow[] drr = JobDT.Select();
                    for (int i = 0; i < drr.Length; i++)
                    {
                        if (JobDT.Rows[i]["JobCode"].ToString() != ""
                            & JobDT.Rows[i]["Amount"].ToString() != "")
                        {
                            JobCardDetail_Insert_param[0].Value = Session["DealerCode"].ToString();
                            JobCardDetail_Insert_param[1].Value = CustomerEstimateCode.Trim();
                            JobCardDetail_Insert_param[2].Value = JobDT.Rows[i]["JobCode"].ToString();
                            JobCardDetail_Insert_param[3].Value = JobDT.Rows[i]["JobRemarks"].ToString();
                            JobCardDetail_Insert_param[4].Value = Convert.ToDecimal(JobDT.Rows[i]["Amount"].ToString());
                            SysFunc.ExecuteSP_NonQuery("sp_2W_CustomerEstimate_Detail_Insert", JobCardDetail_Insert_param, Trans);
                            flag = true;
                        }
                    }
                    // }
                }
                return flag;
            }
            catch (Exception ex) { throw ex; }
        }

        //Insert CustomerEstimeParts
        private bool Inser_CustomerEstimePartsDetail()
        {
            try
            {
                bool flag = false;
                SqlParameter[] CustomerEstimePartsDetail_Delete_param = {                                                       
                                                                    new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                                                    new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8)
                                                                 };
                CustomerEstimePartsDetail_Delete_param[0].Value = Session["DealerCode"].ToString();
                CustomerEstimePartsDetail_Delete_param[1].Value = CustomerEstimateCode.Trim();

                SqlParameter[] CustomerEstimePartsDetail_Insert_param = {                                                       
                                                                    new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                                                    new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8),
                                                                    new SqlParameter("@ItemCode",SqlDbType.VarChar,8),
                                                                    new SqlParameter("@PartNo",SqlDbType.Char,18),
                                                                    new SqlParameter("@Qty",SqlDbType.VarChar,10),
                                                                    new SqlParameter("@Price",SqlDbType.VarChar,50),
                                                                    new SqlParameter("@Dep",SqlDbType.VarChar,3)
                                                                 };

                if (SysFunc.ExecuteSP_NonQuery("sp_2W_CustomerEstimateParts_PartsDetail_Delete", CustomerEstimePartsDetail_Delete_param, Trans))
                {
                    PartsDT = (DataTable)ViewState["Parts"];
                    DataRow[] drr = PartsDT.Select();
                    for (int i = 0; i < drr.Length; i++)
                    {
                        CustomerEstimePartsDetail_Insert_param[0].Value = Session["DealerCode"].ToString();
                        CustomerEstimePartsDetail_Insert_param[1].Value = CustomerEstimateCode.Trim();
                        if (PartsDT.Rows[i]["ItemCode"].ToString() != "")
                        {
                            CustomerEstimePartsDetail_Insert_param[2].Value = PartsDT.Rows[i]["ItemCode"].ToString(); //Item Code System Generted num. Get it from lookup
                            CustomerEstimePartsDetail_Insert_param[3].Value = PartsDT.Rows[i]["PartNo"].ToString();
                            CustomerEstimePartsDetail_Insert_param[4].Value = PartsDT.Rows[i]["Qty"].ToString();
                            CustomerEstimePartsDetail_Insert_param[5].Value = PartsDT.Rows[i]["Price"].ToString();
                            CustomerEstimePartsDetail_Insert_param[6].Value = PartsDT.Rows[i]["Dep"].ToString();                            
                                SysFunc.ExecuteSP_NonQuery("sp_2W_CustomerEstimatePartsDetail_Insert", CustomerEstimePartsDetail_Insert_param, Trans);
                            flag = true;
                        }
                    }
                }
                // }
                return flag;
            }
            catch (Exception ex) { throw ex; }
        }

        private bool Inser_CustomerEstimateLubricates_Detail()
        {
            try
            {
                bool flag = false;
                SqlParameter[] CustomerEstimateLubricanteDetail_Delete_param = {                                                       
                                                                    new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                                                    new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8)
                                                                  };
                CustomerEstimateLubricanteDetail_Delete_param[0].Value = Session["DealerCode"].ToString();
                CustomerEstimateLubricanteDetail_Delete_param[1].Value = CustomerEstimateCode.Trim();

                SqlParameter[] CustomerEstimateLubricanteDetail_Insert_param = {                                                       
                                                                    new SqlParameter("@DealerCode",SqlDbType.Char,5),
                                                                    new SqlParameter("@CustomerEstimateCode",SqlDbType.Char,8),
                                                                    new SqlParameter("@ItemCode",SqlDbType.VarChar,8),
                                                                    new SqlParameter("@PartNo",SqlDbType.Char,18),
                                                                    new SqlParameter("@Qty",SqlDbType.VarChar,10),
                                                                    new SqlParameter("@Price",SqlDbType.VarChar,50),
                                                                  };

                if (SysFunc.ExecuteSP_NonQuery("sp_W2_CustomerEstimate_LubricanteDetail_Delete", CustomerEstimateLubricanteDetail_Delete_param, Trans))
                {
                    LubDT = (DataTable)ViewState["Lub"];
                    DataRow[] drr = LubDT.Select();
                    for (int i = 0; i < drr.Length; i++)
                    {
                        CustomerEstimateLubricanteDetail_Insert_param[0].Value = Session["DealerCode"].ToString();
                        CustomerEstimateLubricanteDetail_Insert_param[1].Value = CustomerEstimateCode.Trim();
                        if (LubDT.Rows[i]["ItemCode"].ToString() != "")
                        {
                            CustomerEstimateLubricanteDetail_Insert_param[2].Value = LubDT.Rows[i]["ItemCode"].ToString(); ; //Item Code System Generted num. Get it from lookup
                            CustomerEstimateLubricanteDetail_Insert_param[3].Value = LubDT.Rows[i]["PartNo"].ToString();
                            CustomerEstimateLubricanteDetail_Insert_param[4].Value = LubDT.Rows[i]["Qty"].ToString();
                            CustomerEstimateLubricanteDetail_Insert_param[5].Value = LubDT.Rows[i]["Price"].ToString();
                            if (SysFunc.ExecuteSP_NonQuery("sp_2W_CustomerEstimateLubricates_LubricanteDetail_Insert", CustomerEstimateLubricanteDetail_Insert_param, Trans))
                            {
                                flag = true;
                            }
                            else
                            {
                                flag = false;
                            }

                        }
                    }
                }
                // }
                return flag;
            }
            catch (Exception ex) { throw ex; }

        }


        private bool rowsInJobCardDetail(GridView gvJobCard)
        {
            search_item = false;
            foreach (GridViewRow row in gvJobCard.Rows) { if (row.Cells[2].Text.Replace("&nbsp;", "").Trim() != "") search_item = true; }
            return search_item;
        }

        private bool rowInJobCardPartsDetail(GridView gvJobCardParts)
        {
            search_item = false;
            foreach (GridViewRow row in gvJobCardParts.Rows) { if (row.Cells[2].Text.Replace("&nbsp;", "").Trim() != "") search_item = true; }
            return search_item;
        }

        private bool rowInJobCardLubricanteDetail(GridView gvLubParts)
        {
            search_item = false;
            foreach (GridViewRow row in gvLubParts.Rows) { if (row.Cells[2].Text.Replace("&nbsp;", "").Trim() != "") search_item = true; }
            return search_item;
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        protected void clearAll()
        {
            ddlEstCode.SelectedIndex = 0;
            //ddlParts.SelectedIndex = 0;
            ddllLubs.SelectedIndex = 0;
            txtEstCode.Text = "";
            ddlJobCardType.SelectedIndex = 0;
            ddlInsuranceComp.SelectedIndex = 0;
            ddlInsBranch.SelectedIndex = 0;
            txtConvyer.Text = "";
            txtChassisNo.Text = "";
            txtEngineNo.Text = "";
            txtCustomer.Text = "";
            txtCustomerDesc.Text = "";
            txtEndUser.Text = "";
            txtEndUserDesc.Text = "";
            txtBrand.Text = "";
            txtBrandDesc.Text = "";
            txtProduct.Text = "";
            txtVersion.Text = "";
            txtVersionDesc.Text = "";
            txtRemarks.Text = "";
            ddlAdvisor.SelectedIndex = 0;
            createLubDT();
            createPartsDT();
            createJobDT();
            setInitialDates();
            ClearJobTextBoxes();
            ClearPartsTextBoxes();
            ClearLubricantsTextBoxes();
            //txtPartTotalQuantity.Text = txtPartsTotal.Text =
            //lbltotLubQty.Text = txtLubTotal.Text =
            //lblJobCardTotal.Text = txtJobsTotal.Text = "0";
            txtDep.Text = string.Empty;
            ddlRegNo.SelectedIndex = 0;
        }



      
        protected void btnPrint_Click(object sender, EventArgs e)
        {
            //string PDFFileName = MakeReport();

            //string URL = "../../../Download/OpenPdf.aspx?FileName=" + PDFFileName;
            string URL = "../../../Download/rptViewerService.aspx?ReportID=CustomerEstimate&CustEstimateCode=" + ddlEstCode.SelectedValue.ToString().Trim() +"";
            //URL = FilePath + "OpenPdf.aspx?FileName=" + FileName;
            //txtPartItemDesc.Text = URL;
            string fullsysURL = "window.open('" + URL + "', '_blank', 'height=800,width=1000,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes,titlebar=no');";
            ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", fullsysURL, true);
        }
        protected void btnDelete_Click1(object sender, EventArgs e)
        {
            if (ddlEstCode.SelectedIndex==0)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Select Estimate code first. ");
                txtEstCode.Focus();
                return;
            }
            if (SysFunc.CodeExists("JobCardMaster", "EstimateCode", ddlEstCode.SelectedValue.ToString (), " And DelFlag='N'"))
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Estimate Code exist in Job Card ,it can not be deleted ");
                return;
            }

            if (Delete(ddlEstCode.SelectedValue.ToString ().Trim()) == false)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Customer Estimate code not deleted Try again");
                return;
            }
            else
            {
                SysFunc.UserMsg(lblMsg, Color.Green, "Customer Estimate Code deleted successfully ");
                //SendAlert("Customer Estimate Code deleted successfully !!!");
                clearAll();
            }

        }


        //Delete Customer Estimate Code
        public bool Delete(string strCode)
        {
            //#BEGIN TRANSACTION
            SqlTransaction stDeleteJobCard = null;
            //#IF TRANSACTION COULD'NT BE STARTED RETURN FALSE
            if ((!ObjTrans.BeginTransaction(ref stDeleteJobCard)))
            {
                return false;
            }

            //1. Only CustomerEstimateMaster update value wiht DelFalg Y
            string sJobCardMasterUpdateQuery = "Update CustomerEstimateMaster Set DelFlag = 'Y',UpdUser = '" + Session["UserName"] + "',UpdDate = '" + SysFunc.SaveDate(DateTime.Now.ToString("dd/MM/yyyy")) + "',UpdTime = '" + DateTime.Now.ToString("HH:mm:ss") + "', UpdTerm = '" + GlobalVar.mUserIPAddress + "' Where CustomerEstimateCode='" + strCode + "' and DealerCode = '" + Session["DealerCode"] + "'";
            try
            {
                if ((!SysFunc.ExecuteQuery_NonQuery(sJobCardMasterUpdateQuery, stDeleteJobCard)))
                {
                    //IF THE step return false exit from the function
                    ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                    return false;
                }
            }
            catch (Exception ex)
            {
                ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                SysFunc.UserMsg(lblMsg, Color.Red, "Error: " + ex.Message);
                
                return false;
            }

            //2. DELETE FROM CustomerEstimateDetail
            string sJobCardDetailDeleteQuery = "DELETE FROM CustomerEstimateDetail Where CustomerEstimateCode='" + strCode + "' and DealerCode = '" + Session["DealerCode"].ToString() + "'";
            try
            {
                if ((!SysFunc.ExecuteQuery_NonQuery(sJobCardDetailDeleteQuery, stDeleteJobCard)))
                {
                    //IF THE step return false exit from the function
                    ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                    return false;
                }
            }
            catch (Exception ex)
            {
                ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                SysFunc.UserMsg(lblMsg, Color.Red, "Error: " + ex.Message);
                
                return false;
            }

            //3. DELETE FROM CustomerEstimateParts
            string sJobCardPartDeleteQuery = "DELETE FROM CustomerEstimateParts Where CustomerEstimateCode='" + strCode + "' and DealerCode = '" + Session["DealerCode"].ToString() + "'";
            try
            {
                if ((!SysFunc.ExecuteQuery_NonQuery(sJobCardPartDeleteQuery, stDeleteJobCard)))
                {
                    //IF THE step return false exit from the function
                    ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                    return false;
                }
            }
            catch (Exception ex)
            {
                ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                SysFunc.UserMsg(lblMsg, Color.Red, "Error: " + ex.Message);
                
                return false;
            }

            //4.DELETE FROM CustomerEstimateLubricates
            string sJobCardLubDeleteQuery = "DELETE FROM CustomerEstimateLubricates Where CustomerEstimateCode='" + strCode + "' and DealerCode = '" + Session["DealerCode"].ToString() + "'";
            try
            {
                if ((!SysFunc.ExecuteQuery_NonQuery(sJobCardLubDeleteQuery, stDeleteJobCard)))
                {
                    //IF THE step return false exit from the function
                    ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                    return false;
                }
            }
            catch (Exception ex)
            {
                ObjTrans.RollBackTransaction(ref stDeleteJobCard);
                SysFunc.UserMsg(lblMsg, Color.Red, "Error: " + ex.Message);
                
                return false;
            }

            //#COMMIT TRANSACTION
            ObjTrans.CommittTransaction(ref stDeleteJobCard);
            return true;
        }

        //protected void lnkRemove_Click2(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        LubDT = (DataTable)ViewState["Lub"];
        //        LinkButton btn = sender as LinkButton;
        //        TableCell tc = btn.Parent as TableCell;
        //        GridViewRow gvr = tc.Parent as GridViewRow;
        //        LubDT.Rows.RemoveAt(gvr.RowIndex);
        //        //Load grid 
        //        gvLubParts.DataSource = LubDT;
        //        LubDT.AcceptChanges();
        //        gvLubParts.DataBind();
        //        if (LubDT.Rows.Count == 0)
        //        {
        //            txtLubTotal.Text = "0";
        //            lbltotLubQty.Text = "0";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        SysFunc.UserMsg(lblMsg, Color.Red, ex.Message, txtPartCode);
        //    }
        //}
        //protected void lnkRemove_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        PartsDT = (DataTable)ViewState["Parts"];
        //        LinkButton btn = sender as LinkButton;
        //        TableCell tc = btn.Parent as TableCell;
        //        GridViewRow gvr = tc.Parent as GridViewRow;
        //        PartsDT.Rows.RemoveAt(gvr.RowIndex);
        //        //Load grid 
        //        gvJobCardParts.DataSource = PartsDT;
        //        PartsDT.AcceptChanges();
        //        gvJobCardParts.DataBind();
        //        int sumParts = 0;

        //        if (PartsDT.Rows.Count <= 0)
        //        {
        //            txtPartsTotal.Text = "0";
        //            txtPartTotalQuantity.Text = "0";
        //        }
        //        else
        //        {
        //            foreach (DataRow dr in PartsDT.Rows)
        //            {
        //                sumParts = sumParts + Convert.ToInt32(dr["Qty"].ToString());
        //            }
        //            txtPartTotalQuantity.Text = sumParts.ToString();
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        SysFunc.UserMsg(lblMsg, Color.Red, ex.Message, txtPartCode);
        //    }
        //}
        //protected void lnkRemove_Click1(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        JobDT = (DataTable)ViewState["Job"];
        //        LinkButton btn = sender as LinkButton;
        //        TableCell tc = btn.Parent as TableCell;
        //        GridViewRow gvr = tc.Parent as GridViewRow;
        //        JobDT.Rows.RemoveAt(gvr.RowIndex);
        //        //Load grid 
        //        gvJobCard.DataSource = JobDT;
        //        JobDT.AcceptChanges();
        //        gvJobCard.DataBind();
        //        if (JobDT.Rows.Count == 0)
        //        {
        //            txtJobsTotal.Text = "0";
        //            lblJobCardTotal.Text = "0";
        //        }
        //        else
        //        {
        //            txtJobsTotal.Text = JobDT.Rows.Count.ToString();

        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        SysFunc.UserMsg(lblMsg, Color.Red, ex.Message, txtPartCode);
        //    }
        //}
       
        private void Insert_in_JobDT(DataRow rowJobDT)
        {
            rowJobDT["JobCode"] = ddlJobs.SelectedValue; rowJobDT["DefJobDesc"] = ddlJobs.SelectedItem.Text;
            rowJobDT["JobRemarks"] = "";
            rowJobDT["Amount"] = txtLabor.Text;

            if (lblTotalAMount.Text != "")
            {
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(lblTotalAMount.Text) + Convert.ToInt32(txtLabor.Text));
            }
            else
            {
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(txtLabor.Text));
            }

        }

        public bool MasterValidation(TextBox[] textBoxes)
        {
            bool isValid = true;

            for (int i = 0; i < textBoxes.Length; i++)
            {
                if (textBoxes[i].Text.Trim() == "")
                {
                    isValid = false;
                    textBoxes[i].BorderColor = System.Drawing.Color.Red;
                    SetFocus(textBoxes[i]);
                    SysFunc.UserMsg(lblMsg, Color.Red, "Error: Field(s) Marked With Red Steriks '*' Are Mendetory...");
                    break;
                }
            }
            return isValid;
        }

        private void ClearJobTextBoxes()
        {
            TextBox[] txts = {  txtLabor };
            ClearTextBoxes(txts);
            ddlJobs.SelectedIndex = 0;
        }
        public void ClearTextBoxes(TextBox[] textBoxes)
        {
            for (int i = 0; i < textBoxes.Length; i++)
            { textBoxes[i].Text = string.Empty; }
        }
       
        //protected void btnJobCardRemove_Click(object sender, EventArgs e)
        //{
        //    JobDT = (DataTable)ViewState["Job"];
        //    JobDT.Rows.Remove(JobDT.Rows[ridx]);
        //    JobDT.AcceptChanges();
        //    ViewState["Job"] = JobDT; gvJobCard.DataSource = JobDT; gvJobCard.DataBind();
        //}
       
       
       
        private void ClearPartsTextBoxes()
        {
            TextBox[] txts = { txtQuantity, txtItemCode, txtItemDesc, txtPartPrice, txtItemCode, txtDep ,txtItemNo};
            ClearTextBoxes(txts); txtPartsRecQuantity.Text = "0";
            //ddlParts.SelectedIndex = 0;
        }

        private void Insert_in_PartsDT(DataRow rowPartsDT)
        {
            rowPartsDT["PartNo"] = txtItemNo.Text.Trim(); rowPartsDT["PartsDesc"] = txtItemDesc.Text.Trim();
            if (ddlJobCardType.SelectedValue == "Insurance")
            {
                if (txtDep.Text.Trim() == string.Empty)
                {
                    txtDep.Text = "0";
                }
                rowPartsDT["Dep"] = txtDep.Text.Trim();
                rowPartsDT["DepAmount"] = (Math.Round((double.Parse(txtQuantity.Text.Trim()) * double.Parse(txtPartPrice.Text.Trim()) / 100) * double.Parse(txtDep.Text.Trim())));
            }
            else
            {
                rowPartsDT["Dep"] = "0";
                rowPartsDT["DepAmount"] = "0";
            }

            rowPartsDT["Qty"] = txtQuantity.Text.Trim(); rowPartsDT["Price"] = txtPartPrice.Text.Trim();
            rowPartsDT["Total"] = double.Parse(txtQuantity.Text.Trim()) * double.Parse(txtPartPrice.Text.Trim());
            rowPartsDT["ItemCode"] = txtItemCode.Text.Trim();

            if (lblTotalAMount.Text != "")
            {
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(lblTotalAMount.Text) + Convert.ToInt32(double.Parse(txtQuantity.Text.Trim()) * double.Parse(txtPartPrice.Text.Trim())));
            }
            else
            {
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(double.Parse(txtQuantity.Text.Trim()) * double.Parse(txtPartPrice.Text.Trim())));
            }

        }
        
        
      
       

        private void ClearLubricantsTextBoxes()
        {
            TextBox[] txts = { txtLubPartCode, txtLubPartDesc, txtLubPrice, txtLubQuantity, txtItemcodeLub };
            ClearTextBoxes(txts);
            txtLubRecQuantity.Text = "0";
            ddllLubs.SelectedIndex = 0;
        }

        private void Insert_in_LubPartsDT(DataRow rowLubDT)
        {
            rowLubDT["PartNo"] = txtLubPartCode.Text.Trim(); rowLubDT["PartsDesc"] = txtLubPartDesc.Text.Trim();
            rowLubDT["Qty"] = txtLubQuantity.Text.Trim(); rowLubDT["Price"] = txtLubPrice.Text.Trim();
            rowLubDT["Total"] = double.Parse(txtLubQuantity.Text.Trim()) * double.Parse(txtLubPrice.Text.Trim());
            rowLubDT["ItemCode"] = txtItemcodeLub.Text.Trim();
            if (lblTotalAMount.Text != "")
            {
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(lblTotalAMount.Text) + Convert.ToInt32(double.Parse(txtLubQuantity.Text.Trim()) * double.Parse(txtLubPrice.Text.Trim())));
            }
            else
            {
                lblTotalAMount.Text = Convert.ToString(Convert.ToInt32(double.Parse(txtLubQuantity.Text.Trim()) * double.Parse(txtLubPrice.Text.Trim())));
            }
        }
        
        protected void gvLubParts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //countlub = countlub + int.Parse(e.Row.Cells[5].Text.Replace("&nbsp;", "").Trim() == "" ? "0" : e.Row.Cells[5].Text.Replace("&nbsp;", "").Trim());
                Label lblRowLubsAmount = (Label)e.Row.Cells[6].FindControl("lblRowLubsAmount");
                totlub = totlub + double.Parse(lblRowLubsAmount.Text.Replace("&nbsp;", "").Trim() == "" ? "0" : lblRowLubsAmount.Text.Replace("&nbsp;", "").Trim());
            }
            else if (e.Row.RowType == DataControlRowType.Header)
            {
                totlub = 0; countlubRecQty = countlub = 0;
            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {
                Label lblFooterLubsAmount = (Label)e.Row.FindControl("lblFooterLubsAmount");
                lblFooterLubsAmount.Text = totlub.ToString();
                //lbltotLubQty.Text = countlub.ToString(); txtLubTotal.Text = totlub.ToString();
                //txttotLubRecQty.Text = countlubRecQty.ToString();
            }
        }
        //protected void gvLubParts_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ViewState["ridx"] = gvLubParts.SelectedRow.RowIndex;
        //        GridViewRow row = gvLubParts.Rows[gvLubParts.SelectedRow.RowIndex];
        //        ViewState["deductAmount"] = (Convert.ToDecimal(row.Cells[5].Text) * Convert.ToDecimal(row.Cells[7].Text)).ToString();
        //        txtItemcodeLub.Text = row.Cells[2].Text;
        //        ddllLubs.SelectedValue = txtItemcodeLub.Text;
        //        txtLubPartCode.Text = row.Cells[3].Text;
        //        txtLubPartDesc.Text = row.Cells[4].Text;
        //        txtLubQuantity.Text = row.Cells[5].Text;
        //        txtLubPrice.Text = row.Cells[6].Text;
        //    }
        //    catch (Exception ex) { throw ex; }
        //}
        //protected void gvJobCardParts_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ViewState["ridx"] = gvJobCardParts.SelectedRow.RowIndex;
        //        GridViewRow row = gvJobCardParts.Rows[gvJobCardParts.SelectedRow.RowIndex];

        //        txtItemcodeParts.Text = row.Cells[2].Text;
        //        ddlParts.SelectedValue = txtItemcodeParts.Text;
        //        txtPartCode.Text = row.Cells[3].Text;
        //        txtPartDesc.Text = row.Cells[4].Text;
        //        txtPartsRecQuantity.Text = row.Cells[7].Text;
        //        txtQuantity.Text = row.Cells[7].Text;
        //        txtPartPrice.Text = row.Cells[8].Text;
        //        ViewState["deductAmount"] = row.Cells[9].Text;

        //    }
        //    catch (Exception ex) { throw ex; }
        //}
        protected void gvJobCardParts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblRowPartAmount = (Label)e.Row.Cells[9].FindControl("lblRowPartAmount");
                totParts = totParts + int.Parse(lblRowPartAmount.Text.Replace("&nbsp;", "").Trim() == "" ? "0" : lblRowPartAmount.Text.Replace("&nbsp;", "").Trim());
                //totParts = totParts + double.Parse(e.Row.Cells[7].Text.Replace("&nbsp;", "").Trim() == "" ? "0" : e.Row.Cells[7].Text.Replace("&nbsp;", "").Trim());
                //countParts = countParts + int.Parse(e.Row.Cells[8].Text.Replace("&nbsp;", "").Trim() == "" ? "0" : e.Row.Cells[8].Text.Replace("&nbsp;", "").Trim());
            }
            else if (e.Row.RowType == DataControlRowType.Header)
            {
                totParts = 0;
                countPartsRecQty = countParts = 0;
            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {
                Label lblFooterPartAmount = (Label)e.Row.FindControl("lblFooterPartAmount");
                lblFooterPartAmount.Text = totParts.ToString();
            }
        }
        //protected void gvJobCard_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ViewState["ridx"] = gvJobCard.SelectedRow.RowIndex;
        //        GridViewRow row = gvJobCard.Rows[gvJobCard.SelectedRow.RowIndex];
        //        ddlJobs.SelectedValue = row.Cells[2].Text;
        //        txtJobRemarks.Text = (row.Cells[4].Text != "&nbsp;" ? row.Cells[4].Text : "");
        //        txtLabor.Text = row.Cells[5].Text;
        //    }
        //    catch (Exception ex) { throw ex; }
        //}
        protected void gvJobCard_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblRowAmount = (Label)e.Row.Cells[4].FindControl("lblRowAmount");
                totLabour = totLabour + double.Parse(lblRowAmount.Text.Replace("&nbsp;", "") == "" ? "0" : lblRowAmount.Text);
            }
            else if (e.Row.RowType == DataControlRowType.Header)
            {
                countLabour = 0;
                totLabour = 0;
            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {
                Label lblFooterAmount = (Label)e.Row.FindControl("lblFooterAmount");
                lblFooterAmount.Text = totLabour.ToString();
                //lblJobCardTotal.Text = totLabour.ToString();
                //txtJobsTotal.Text = countLabour.ToString();
            }
        }

        protected void ddlJobCardType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlJobCardType.SelectedValue == "Insurance")
            {
                lblBranch.Visible = true;
                lblInsuranceComp.Visible = true;
                lblBranch.Visible = true;
                lblConveyer.Visible = true;
                ddlInsuranceComp.Visible = true;
                ddlInsBranch.Visible = true;
                txtConvyer.Visible = true;
            }
            else
            {
                lblBranch.Visible = false;
                lblInsuranceComp.Visible = false;
                lblBranch.Visible = false;
                lblConveyer.Visible = false;
                ddlInsuranceComp.Visible = false;
                ddlInsBranch.Visible = false;
                txtConvyer.Visible = false;
            }

        }

        protected void ddlRegNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ddlRegNo.SelectedIndex==0)
            {
                return;
            }
            LoadVehInfo();
        }

        //protected void ddlParts_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    //if (ddlParts.SelectedItem.Text == "Select")
        //    //{
        //    //    return;
        //    //}
        //    DataSet ds = new DataSet();
        //  //  string strQuery = "Select " +
        //  //   "A.ItemCode, " +
        //  //   "A.ItemDesc, " +
        //  //   "A.UnitCode, " +
        //  //   "A.PartItemNo, " +
        //  //   "A.SaleRate, " +
        //  //   "IsNull(Sum(B.RecQty) + Sum(B.RetQty) - Sum(B.IssQty) - Sum(B.ChargeOutQty) - Sum(B.PurRetQty), 0) As [Quantity] " +
        //  //   "From    " +
        //  //   "Item A  " +
        //  //   "Left outer join ItemStock B    " +
        //  // "ON    " +
        //  // "A.ItemCode = B.ItemCode And    " +
        //  //"B.DealerCode = '" + Session["DealerCode"].ToString() + "' " +
        //  //"And A.ItemCode='" + ddlParts.SelectedValue.ToString().Trim() + "' " +
        //  //"Group by " +
        //  //"A.ItemCode, " +
        //  //   "A.ItemDesc, " +
        //  //   "A.UnitCode, " +
        //  //   "A.PartItemNo," +
        //  //   "A.SaleRate";
        //    string strQuery = "SELECT * FROM ITEM WHERE DealerCode='" + Session["DealerCode"] + "' And ItemCode= '" + txtPartCode.SelectedValue.ToString().Trim()+"'";
        //    SysFunc.ExecuteQuery(strQuery,ref ds);
        //    txtPartDesc.Text = ds.Tables[0].Rows[0]["ItemDesc"].ToString();
        //    txtPartCode.Text=ds.Tables[0].Rows[0]["PartItemNo"].ToString();
        //    txtPartPrice.Text = Convert.ToInt32 (ds.Tables[0].Rows[0]["SaleRate"]).ToString();
        //    txtItemcodeParts.Text = ds.Tables[0].Rows[0]["ItemCode"].ToString();
        //    //txtPartsRecQuantity.Text = ds.Tables[0].Rows[0]["Quantity"].ToString();
        //}

        protected void SelectedPartDetail(string item)
        {
            try
            {                
                DataTable dt = new DataTable();
                dt = SysFunc.GetData("select ItemDesc,SaleRate,PartItemNo from Item where DealerCode='" + Session["DealerCode"].ToString() + "' And  ItemCode='" + item + "'");
                txtItemCode.Text = item;
                txtItemDesc.Text = dt.Rows[0]["ItemDesc"].ToString().Trim();
                txtItemNo.Text = dt.Rows[0]["PartItemNo"].ToString().Trim();
                txtPartPrice.Text = Convert.ToInt32(dt.Rows[0]["SaleRate"]).ToString();
            }
            catch (Exception ex)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, ex.Message);
            }
        }


        protected void ddllLubs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddllLubs.SelectedItem.Text == "Select")
            {
                return;
            }
            DataSet ds = new DataSet();
            SysFunc.ExecuteQuery("Select * From Item Where ItemCode='" + ddllLubs.SelectedValue.ToString().Trim() + "'", ref ds);
            txtLubPartDesc.Text = ds.Tables[0].Rows[0]["ItemDesc"].ToString();
            txtLubPartCode.Text =ds.Tables[0].Rows[0]["PartItemNo"].ToString();
            txtItemcodeLub.Text = ds.Tables[0].Rows[0]["ItemCode"].ToString();
            txtLubPrice.Text =Convert .ToInt32 ( ds.Tables[0].Rows[0]["SaleRate"]).ToString();
        }

        protected void ddlEstCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ddlEstCode.SelectedIndex==0)
            {
                return;
            }
            LoadMasterData();
        }
        private string MakeReport()
        {
            ReportDocument  RD;
            //string strCriteria, rptTitle;
            //DateTime FromDate, ToDate;
            //SqlDataReader rder;
            SysFunctions myFunc = new SysFunctions();
            Data.DSReports DsRpt = new Data.DSReports();
            DataSet1 dsRpt1 = new DataSet1();
            
            RD = new ReportDocument();
            string CCon = CConnection.GetConnectionString();
            DataSet ds = new DataSet();

            ds = SqlHelper.ExecuteDataset(CCon, CommandType.Text, "sp_CustomerEstimateMaster_Print '" + this.Session["DealerCode"].ToString() + "','" + ddlEstCode.SelectedValue.ToString ().Trim() + "'");
            DsRpt.sp_CustomerEstimateMaster_Print.Load(ds.CreateDataReader());

            ds = SqlHelper.ExecuteDataset(CCon, CommandType.Text, "sp_CustomerEstimateDetail_Print '" + this.Session["DealerCode"].ToString() + "','" + ddlEstCode.SelectedValue.ToString().Trim() + "'");
            DsRpt.sp_CustomerEstimateDetail_Print.Load(ds.CreateDataReader());

            ds = SqlHelper.ExecuteDataset(CCon, CommandType.Text, "sp_CustomerEstimateLubricates_Print '" + this.Session["DealerCode"].ToString() + "','" + ddlEstCode.SelectedValue.ToString().Trim() + "'");
            DsRpt.sp_CustomerEstimateLubricates_Print.Load(ds.CreateDataReader());

            ds = SqlHelper.ExecuteDataset(CCon, CommandType.Text, "sp_CustomerEstimateParts_Print '" + this.Session["DealerCode"].ToString() + "','" + ddlEstCode.SelectedValue.ToString().Trim() + "'");
            DsRpt.sp_CustomerEstimateParts_Print.Load(ds.CreateDataReader());

            //ds = SqlHelper.ExecuteDataset(CCon, CommandType.Text, "sp_JobCardSubletDetail_Print'" + this.Session["DealerCode"].ToString() + "','" + ddlJobCardNo.Text.Trim() + "'");
            //DSReports.sp_JobCardSubletDetail_Print.Load(ds.CreateDataReader());

            //string FileRptPath = Server.MapPath("~/Modules/Service/ServiceReports/");


            RD.Load(Server.MapPath("~/Modules/Service/ServiceReports/rptCustomerEstimatePrint.rpt"));
            RD.OpenSubreport(Server.MapPath("~/Modules/Service/ServiceReports/rptCustomerEstimateDetail.rpt"));
            RD.OpenSubreport(Server.MapPath("~/Modules/Service/ServiceReports/rptCustomerEctimatePartsDetail.rpt"));
            RD.OpenSubreport(Server.MapPath("~/Modules/Service/ServiceReports/rptCustomerEstimateLubDetail.rpt"));

            RD.DataDefinition.FormulaFields["DealerName"].Text = "'" + Session["DealerDesc"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerAddress"].Text = "'" + Session["DealerAddress"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerPhone"].Text = "'" + Session["DealerPhone"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerEmail"].Text = "'" + Session["DealerEmail"].ToString() + "'";
            RD.DataDefinition.FormulaFields["ReportTitle"].Text = "'CUSTOMER ESTIMATE'";
            RD.DataDefinition.FormulaFields["Terminal"].Text = "'" + Request.ServerVariables["REMOTE_ADDR"].ToString() + "'";
            RD.DataDefinition.FormulaFields["UserId"].Text = "'" + Session["UserName"].ToString() + "'";
            RD.DataDefinition.FormulaFields["NTN"].Text = "'N.T.N # " + Session["DealerNTN"].ToString() + "'";
            RD.DataDefinition.FormulaFields["SalesTaxNo"].Text = "'Sales Tax No.  " + Session["DealerSaleTaxNo"].ToString() + " '";
            //rpt.DataDefinition.FormulaFields["UserCell"].Text = "'" + GetStringValuesAgainstCodes("CusCode", , "CellNo", "Customer") + "'";
            RD.DataDefinition.FormulaFields["CompanyName"].Text = "'" + Session["DealerDesc"].ToString() + "'";
            //RD.DataDefinition.FormulaFields["DealershipName"].Text = "'Authorised " + Session["ParentDesc"].ToString() + " Dealership'";
            //RD.DataDefinition.FormulaFields["Pic"].Text = "'C:\\Users\\u_ahm\\OneDrive\\Documents\\Visual Studio 2010\\Projects\\WebApplication1\\WebApplication1\\" + Session["Logo"] + "'";
            RD.DataDefinition.FormulaFields["Pic"].Text = "'" + Server.MapPath("~") + Session["Logo"] + "'";
            // CrystalReportViewer1.ReportSource = rpt;
            RD.SetDataSource(DsRpt.sp_CustomerEstimateMaster_Print.DataSet);

            Session["RDService"] = RD;

            // prepare pdf and show

            // create pdf 
            string FilePath = Server.MapPath("~/Download/");
            string FileName = "CustomerEstimate" + Session["DealerCode"].ToString() + DateTime.Now.ToString("ddMMyyyy") + ".pdf";
            string File = FilePath + FileName;
            //crReportDocument.SetDatabaseLogon("SDMS", "sdms161", "192.168.1.47", "SDMS");
            RD.ExportToDisk(ExportFormatType.PortableDocFormat, File);




            //crReportDocument = new ReportDocument();
            //crReportDocument = (ReportDocument)Session["RDService"];

            ////CrystalReportViewer1.ReportSource = crReportDocument;
            ////return;

            //string FilePath = Server.MapPath("~/Download/");
            //string FileName = "JobCard" + this.Session["DealerCode"].ToString() + DateTime.Now.ToString("ddMMyyyy") + ".pdf";
            //string File = FilePath + FileName;
            ////Response.Write(File);
            ////crReportDocument.SetDatabaseLogon("SDMS", "sdms161", "192.168.1.47", "SDMS");
            //crReportDocument.ExportToDisk(ExportFormatType.PortableDocFormat, File);
            //RD.ExportToDisk(ExportFormatType.PortableDocFormat, File);

            return FileName;
        }

        protected void BtnRemove_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                JobDT = (DataTable)ViewState["Job"];
                ImageButton btn = sender as ImageButton;
                TableCell tc = btn.Parent as TableCell;
                GridViewRow gvr = tc.Parent as GridViewRow;
                JobDT.Rows.RemoveAt(gvr.RowIndex);
                //Load grid 
                gvJobCard.DataSource = JobDT;
                JobDT.AcceptChanges();
                gvJobCard.DataBind();
                //if (JobDT.Rows.Count == 0)
                //{
                //    txtJobsTotal.Text = "0";
                //    lblJobCardTotal.Text = "0";
                //}
                //else
                //{
                //    txtJobsTotal.Text = JobDT.Rows.Count.ToString();

                //}

            }
            catch (Exception ex)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, ex.Message, txtItemCode);
            }
        }

        protected void BtnRemove_Click1(object sender, ImageClickEventArgs e)
        {
             try
             {
                 PartsDT = (DataTable)ViewState["Parts"];
                 ImageButton btn = sender as ImageButton;
                 TableCell tc = btn.Parent as TableCell;
                 GridViewRow gvr = tc.Parent as GridViewRow;
                 PartsDT.Rows.RemoveAt(gvr.RowIndex);
                 //Load grid 
                 gvJobCardParts.DataSource = PartsDT;
                 PartsDT.AcceptChanges();
                 gvJobCardParts.DataBind();
                 int sumParts = 0;

                 //if (PartsDT.Rows.Count <= 0)
                 //{
                 //    txtPartsTotal.Text = "0";
                 //    txtPartTotalQuantity.Text = "0";
                 //}
                 //else
                 //{
                 //    foreach (DataRow dr in PartsDT.Rows)
                 //    {
                 //        sumParts = sumParts + Convert.ToInt32(dr["Qty"].ToString());
                 //    }
                 //    txtPartTotalQuantity.Text = sumParts.ToString();
                 //}

             }
             catch (Exception ex)
             {
                 SysFunc.UserMsg(lblMsg, Color.Red, ex.Message, txtItemCode);
             }
        }

        protected void BtnRemove_Click2(object sender, ImageClickEventArgs e)
        {
            try
            {
                LubDT = (DataTable)ViewState["Lub"];
                ImageButton btn = sender as ImageButton;
                TableCell tc = btn.Parent as TableCell;
                GridViewRow gvr = tc.Parent as GridViewRow;
                LubDT.Rows.RemoveAt(gvr.RowIndex);
                //Load grid 
                gvLubParts.DataSource = LubDT;
                LubDT.AcceptChanges();
                gvLubParts.DataBind();
                //if (LubDT.Rows.Count == 0)
                //{
                //    txtLubTotal.Text = "0";
                //    lbltotLubQty.Text = "0";
                //}
            }
            catch (Exception ex)
            {
                SysFunc.UserMsg(lblMsg, Color.Red, ex.Message, txtItemCode);
            }
        }

        protected void BtnAdd_Click1(object sender, ImageClickEventArgs e)
        {
            TextBox[] textBoxes = { txtLabor };
            if (ddlJobs.SelectedItem.Text == "--Select--")
            {
                SysFunc.UserMsg(lblMsg, Color.Red, "Please select Job first !!");
                return;
            }
            if (!MasterValidation(textBoxes)) { return; }
            else
            {
                search_result = false;
                foreach (DataRow rowJobDT in JobDT.Rows)
                {
                    if (rowJobDT["JobCode"].ToString().Trim() == ""
                        | rowJobDT["JobCode"].ToString().Trim() == ddlJobs.SelectedValue)
                    {
                        Insert_in_JobDT(rowJobDT); search_result = true;
                    }
                }
                if (search_result == false)
                {
                    DataRow rowJobDT = JobDT.NewRow(); Insert_in_JobDT(rowJobDT); JobDT.Rows.Add(rowJobDT);
                }
                ViewState["Job"] = JobDT; gvJobCard.DataSource = JobDT; gvJobCard.DataBind();
                
                //txtJobsTotal.Text = JobDT.Rows.Count.ToString();
                ClearJobTextBoxes();
            }
        }

        protected void BtnClear1_Click1(object sender, ImageClickEventArgs e)
        {
            ClearJobTextBoxes();
        }

        protected void BtnAdd0_Click(object sender, ImageClickEventArgs e)
        {

            if (txtQuantity.Text.Trim() == "" || txtQuantity.Text.Trim() == "0")
            {
                string script = "alert(\"Quantity should not left blank  !!!\");";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "ServerControlScript", script, true);
                return;
            }


            //lblMsg.Visible = false;
            TextBox[] textBoxes = { txtPartPrice, txtQuantity };
            if (!MasterValidation(textBoxes)) return;
            else
            {
                search_result = false;
                foreach (DataRow rowPartsDT in PartsDT.Rows)
                {
                    if (rowPartsDT["ItemCode"].ToString().Trim() == ""
                        | rowPartsDT["ItemCode"].ToString().Trim() == txtItemCode.Text.Trim())
                    {
                        Insert_in_PartsDT(rowPartsDT); search_result = true;
                    }
                }
                if (search_result == false)
                {
                    DataRow rowPartsDT = PartsDT.NewRow(); Insert_in_PartsDT(rowPartsDT); PartsDT.Rows.Add(rowPartsDT);
                }
                ViewState["Parts"] = PartsDT; gvJobCardParts.DataSource = PartsDT; gvJobCardParts.DataBind();
                //int Count = 0;
                //foreach (DataRow dr in PartsDT.Rows)
                //{
                //    Count = Count + Convert.ToInt32(dr["Qty"]);
                //}
                //txtPartTotalQuantity.Text = Count.ToString();
                ClearPartsTextBoxes();
            }
        }

        protected void BtnClear2_Click(object sender, ImageClickEventArgs e)
        {
            ClearPartsTextBoxes();
        }

        protected void btnLookup_Click(object sender, EventArgs e)
        {
            
            ViewState["lookupid"] = 10; ViewState["ixd1"] = 1; ViewState["ixd2"] = 2; ViewState["ixd3"] = 3;
            clslook.LU_Get_Parts(imgLookup, ViewState["lookupid"].ToString(), "", "../../../");

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Close Look Up Window First')", true);

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            
            TextBox[] textBoxes = { txtLubPartCode, txtLubPrice, txtLubQuantity };
            if (!MasterValidation(textBoxes)) return;
            else
            {
                search_result = false;
                foreach (DataRow rowLubDT in LubDT.Rows)
                {
                    if (rowLubDT["ItemCode"].ToString().Trim() == ""
                        | rowLubDT["ItemCode"].ToString().Trim() == txtItemcodeLub.Text.Trim())
                    {
                        Insert_in_LubPartsDT(rowLubDT); search_result = true;
                    }
                }
                if (search_result == false)
                {
                    DataRow rowLubDT = LubDT.NewRow(); Insert_in_LubPartsDT(rowLubDT); LubDT.Rows.Add(rowLubDT);
                }
                ViewState["Lub"] = LubDT; gvLubParts.DataSource = LubDT; gvLubParts.DataBind();
                ClearLubricantsTextBoxes();
            }
        }
    }
}