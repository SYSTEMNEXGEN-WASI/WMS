﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DXBMS.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;
using System.Data;
using DXBMS;
using CrystalDecisions.Shared;

namespace DXBMS.Modules.SpareParts.SpareReports.Critaria
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SysFunctions sysFunc = new SysFunctions();
        MainBLL ObjMain = new MainBLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Session["UserName"] == null)
            {
                Response.Redirect("~/login.aspx");

            }
            if (!IsPostBack)
            {
                String strQuery = "Select CusCode , CusDesc From Customer where DealerCode ='"+ Session["DealerCode"].ToString() +"'";
                //LoadGRN_DDL();
                ObjMain.FillDropDown(ddlCustomer, strQuery,"CusDesc","CusCode","Select");
                txtFromDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                txtToDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            }
        }

        private void LoadGRN_DDL()
        {
            //string WhereQuery = "1=1";
            //    string[] Columns = new string[] { "RegNo", "App_Id" };
            //    sysFunc.GetMultiColumnsDDL(ddlRegNo, Columns, "CustomerVisit", WhereQuery, "RegNo", "", false, false);

            //string[] col = new string[] { "CusDesc" };
            //sysFunc.GetMultiColumnsDDL(ddlCustomer, col, "Customer", WhereQuery, "CusDesc", "", false, false);
        }

        protected void Print(object sender, EventArgs e)
        {
            Data.DSReports data = new Data.DSReports();
            ReportDocument RD = new ReportDocument();

            DateTime fromDate = DateTime.ParseExact(txtFromDate.Text, "dd-MM-yyyy", null);
            DateTime toDate = DateTime.ParseExact(txtToDate.Text, "dd-MM-yyyy", null);

           
            SqlParameter[] param =
        {
            new SqlParameter("@DealerCode",SqlDbType.Char),//0
            new SqlParameter("@FromDate",SqlDbType.VarChar), //1
            new SqlParameter("@ToDate",SqlDbType.VarChar), //2
            new SqlParameter("@CusCode",SqlDbType.VarChar)

        };

            param[0].Value = Session["DealerCode"].ToString();
            param[1].Value = fromDate.ToString("yyyy-MM-dd");
            param[2].Value = toDate.ToString("yyyy-MM-dd");
            if (ddlCustomer.SelectedIndex == 0)
                param[3].Value = "";
            else
                param[3].Value = ddlCustomer.SelectedValue.ToString().Trim();
            SqlDataReader rder = null;

            

            if (sysFunc.ExecuteSP("SP_PartyLedger_Report", param, ref rder))
            {
                data.SP_PartyLedger_Report.Load(rder);

            }
            rder.Close();
            RD.Load(Server.MapPath("../partyLedgerReport.rpt"));
            

            RD.DataDefinition.FormulaFields["DealerDesc"].Text = "'" + Session["DealerDesc"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerAddress"].Text = "'" + Session["DealerAddress"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerPhone"].Text = "'" + Session["DealerPhone"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerEmail"].Text = "'" + Session["DealerEmail"].ToString() + "'";
            RD.DataDefinition.FormulaFields["DealerFax"].Text = "'" + Session["DealerFax"].ToString() + "'";
            RD.DataDefinition.FormulaFields["ReportTitle"].Text = "'Party Ledger'";
            RD.DataDefinition.FormulaFields["UserID"].Text = "'" + Session["UserName"].ToString() + "'";
            RD.DataDefinition.FormulaFields["Terminal"].Text = "'" + Request.ServerVariables["REMOTE_ADDR"].ToString() + "'";
            RD.DataDefinition.FormulaFields["CompanyName"].Text = "'" + Session["DealerDesc"].ToString() + "'";
            //RD.DataDefinition.FormulaFields["DealershipName"].Text = "'Authorised " + Session["ParentDesc"].ToString() + " Dealership'";
            //RD.DataDefinition.FormulaFields["Pic"].Text = "'C:\\Users\\u_ahm\\OneDrive\\Documents\\Visual Studio 2010\\Projects\\WebApplication1\\WebApplication1\\" + Session["Logo"] + "'";
            RD.DataDefinition.FormulaFields["Pic"].Text = "'" + Server.MapPath("~") + Session["Logo"] + "'";
            RD.Database.Tables[0].SetDataSource(data);

            // convert and show
            string FilePath = Server.MapPath("~") + "\\Download\\";
            string FileName = "crtPartyLedger" + this.Session["DealerCode"].ToString() + DateTime.Now.ToString("ddMMyyyy") + ".pdf";
            string File = FilePath + FileName;
            Session["RD"] = RD;
            //RD.ExportToDisk(ExportFormatType.PortableDocFormat, File);

            string URL;
            URL = "../../../../Download/rptViewerService.aspx?FileName=" + FileName;
            string fullURL = "window.open('" + URL + "', '_blank', 'height=800,width=1200,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes,titlebar=no');";
            ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", fullURL, true);


        }
    }
}